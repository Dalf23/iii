import sqlite3
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the database with required tables"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Stores table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS stores (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER UNIQUE NOT NULL,
                        store_name TEXT NOT NULL,
                        facebook_url TEXT,
                        tiktok_url TEXT,
                        instagram_url TEXT,
                        telegram_id INTEGER NOT NULL,
                        location TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Orders table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS orders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        store_id INTEGER NOT NULL,
                        customer_name TEXT,
                        customer_phone TEXT,
                        order_details TEXT NOT NULL,
                        platform TEXT NOT NULL,
                        status TEXT DEFAULT 'pending',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (store_id) REFERENCES stores (id)
                    )
                ''')
                
                # Inventory table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS inventory (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        store_id INTEGER NOT NULL,
                        item_name TEXT NOT NULL,
                        quantity INTEGER DEFAULT 0,
                        price REAL DEFAULT 0.0,
                        description TEXT,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (store_id) REFERENCES stores (id)
                    )
                ''')
                
                # Messages log table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS messages_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        store_id INTEGER NOT NULL,
                        platform TEXT NOT NULL,
                        message_content TEXT NOT NULL,
                        ai_response TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (store_id) REFERENCES stores (id)
                    )
                ''')
                
                conn.commit()
                logger.info("Database initialized successfully")
                
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {e}")
            raise
    
    def add_store(self, user_id: int, store_data: Dict[str, Any]) -> bool:
        """Add a new store to the database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO stores 
                    (user_id, store_name, facebook_url, tiktok_url, instagram_url, telegram_id, location, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ''', (
                    user_id,
                    store_data.get('name'),
                    store_data.get('facebook'),
                    store_data.get('tiktok'),
                    store_data.get('instagram'),
                    store_data.get('telegram_id'),
                    store_data.get('location')
                ))
                conn.commit()
                logger.info(f"Store added/updated for user {user_id}")
                return True
                
        except sqlite3.Error as e:
            logger.error(f"Error adding store: {e}")
            return False
    
    def get_store_by_user_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Get store information by user ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM stores WHERE user_id = ?', (user_id,))
                row = cursor.fetchone()
                
                if row:
                    columns = [desc[0] for desc in cursor.description]
                    return dict(zip(columns, row))
                return None
                
        except sqlite3.Error as e:
            logger.error(f"Error getting store: {e}")
            return None
    
    def get_all_stores(self) -> List[Dict[str, Any]]:
        """Get all stores (admin function)"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM stores ORDER BY created_at DESC')
                rows = cursor.fetchall()
                
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
                
        except sqlite3.Error as e:
            logger.error(f"Error getting all stores: {e}")
            return []
    
    def delete_store(self, store_id: int) -> bool:
        """Delete a store and all related data"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Delete related records first
                cursor.execute('DELETE FROM orders WHERE store_id = ?', (store_id,))
                cursor.execute('DELETE FROM inventory WHERE store_id = ?', (store_id,))
                cursor.execute('DELETE FROM messages_log WHERE store_id = ?', (store_id,))
                cursor.execute('DELETE FROM stores WHERE id = ?', (store_id,))
                
                conn.commit()
                logger.info(f"Store {store_id} deleted successfully")
                return True
                
        except sqlite3.Error as e:
            logger.error(f"Error deleting store: {e}")
            return False
    
    def add_order(self, store_id: int, order_data: Dict[str, Any]) -> bool:
        """Add a new order"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO orders (store_id, customer_name, customer_phone, order_details, platform)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    store_id,
                    order_data.get('customer_name'),
                    order_data.get('customer_phone'),
                    order_data.get('order_details'),
                    order_data.get('platform')
                ))
                conn.commit()
                logger.info(f"Order added for store {store_id}")
                return True
                
        except sqlite3.Error as e:
            logger.error(f"Error adding order: {e}")
            return False
    
    def get_orders_by_store(self, store_id: int) -> List[Dict[str, Any]]:
        """Get all orders for a specific store"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM orders WHERE store_id = ? ORDER BY created_at DESC
                ''', (store_id,))
                rows = cursor.fetchall()
                
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
                
        except sqlite3.Error as e:
            logger.error(f"Error getting orders: {e}")
            return []
    
    def add_inventory_item(self, store_id: int, item_data: Dict[str, Any]) -> bool:
        """Add or update inventory item"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO inventory 
                    (store_id, item_name, quantity, price, description, updated_at)
                    VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ''', (
                    store_id,
                    item_data.get('name'),
                    item_data.get('quantity', 0),
                    item_data.get('price', 0.0),
                    item_data.get('description')
                ))
                conn.commit()
                logger.info(f"Inventory item added for store {store_id}")
                return True
                
        except sqlite3.Error as e:
            logger.error(f"Error adding inventory item: {e}")
            return False
    
    def get_inventory_by_store(self, store_id: int) -> List[Dict[str, Any]]:
        """Get inventory for a specific store"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM inventory WHERE store_id = ? ORDER BY updated_at DESC
                ''', (store_id,))
                rows = cursor.fetchall()
                
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
                
        except sqlite3.Error as e:
            logger.error(f"Error getting inventory: {e}")
            return []
    
    def log_message(self, store_id: int, platform: str, message_content: str, ai_response: str = None) -> bool:
        """Log a message and AI response"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO messages_log (store_id, platform, message_content, ai_response)
                    VALUES (?, ?, ?, ?)
                ''', (store_id, platform, message_content, ai_response))
                conn.commit()
                return True
                
        except sqlite3.Error as e:
            logger.error(f"Error logging message: {e}")
            return False
