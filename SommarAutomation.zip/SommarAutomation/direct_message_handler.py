import logging
from typing import Dict, List, Optional, Any
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import DatabaseManager
from gemini_ai import GeminiAIManager
from notifications import NotificationManager
from config import EMOJIS, ADMIN_ID

logger = logging.getLogger(__name__)

class DirectMessageHandler:
    def __init__(self, db_manager: DatabaseManager, ai_manager: GeminiAIManager, notification_manager: NotificationManager):
        self.db = db_manager
        self.ai = ai_manager
        self.notifications = notification_manager
    
    async def handle_direct_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE, user_name: str):
        """Handle direct messages from customers with enhanced store matching"""
        message_text = update.message.text
        user_id = update.effective_user.id
        
        try:
            # Get all stores
            all_stores = self.db.get_all_stores()
            
            if not all_stores:
                await update.message.reply_text(
                    f"{EMOJIS['info']} مرحباً! لا توجد متاجر مسجلة حالياً. يرجى المحاولة لاحقاً."
                )
                return
            
            # Enhanced store matching
            best_matches = await self.find_best_matching_stores(message_text, all_stores)
            
            if not best_matches:
                await self.handle_no_match_found(update, user_name, message_text)
                return
            
            # Get the best match
            best_store, best_analysis = best_matches[0]
            
            # Generate smart reply
            smart_reply = self.ai.generate_smart_reply(message_text, best_store)
            
            # Log the message
            self.db.log_message(best_store['id'], 'telegram_direct', message_text, smart_reply)
            
            # Send smart reply to customer
            await update.message.reply_text(
                smart_reply,
                parse_mode='Markdown'
            )
            
            # Handle potential order
            if best_analysis.is_order and best_analysis.confidence > 0.6:
                await self.process_direct_order(
                    update, best_store, best_analysis, user_name, message_text
                )
            
            # Send admin notification about direct message
            await self.notifications.send_admin_notification(
                ADMIN_ID,
                f"رسالة مباشرة جديدة من {user_name} لمتجر {best_store['store_name']}\n"
                f"الرسالة: {message_text[:100]}..."
            )
            
        except Exception as e:
            logger.error(f"Error handling direct message: {e}")
            await update.message.reply_text(
                f"مرحباً {user_name}! شكراً لك على رسالتك. سنقوم بالرد عليك قريباً."
            )
    
    async def find_best_matching_stores(self, message_text: str, all_stores: List[Dict]) -> List[tuple]:
        """Find the best matching stores for a message"""
        matches = []
        
        for store in all_stores:
            try:
                # Analyze message for this store
                analysis = self.ai.analyze_message_for_order(message_text, store)
                
                # Calculate enhanced confidence score
                enhanced_confidence = await self.calculate_enhanced_confidence(
                    message_text, store, analysis
                )
                
                if enhanced_confidence > 0.3:  # Minimum threshold
                    matches.append((store, analysis, enhanced_confidence))
                    
            except Exception as e:
                logger.error(f"Error analyzing message for store {store['id']}: {e}")
                continue
        
        # Sort by enhanced confidence
        matches.sort(key=lambda x: x[2], reverse=True)
        
        # Return top 3 matches
        return [(match[0], match[1]) for match in matches[:3]]
    
    async def calculate_enhanced_confidence(self, message_text: str, store: Dict, analysis) -> float:
        """Calculate enhanced confidence score based on multiple factors"""
        base_confidence = analysis.confidence
        
        # Boost confidence based on store name mention
        message_lower = message_text.lower()
        store_name_lower = store['store_name'].lower()
        
        if store_name_lower in message_lower:
            base_confidence += 0.3
        
        # Boost confidence based on location mention
        if store.get('location') and store['location'].lower() in message_lower:
            base_confidence += 0.2
        
        # Boost confidence based on keywords related to the store
        commerce_keywords = ['أريد', 'أطلب', 'شراء', 'كم سعر', 'متوفر', 'عندك', 'عندكم']
        for keyword in commerce_keywords:
            if keyword in message_lower:
                base_confidence += 0.1
                break
        
        return min(base_confidence, 1.0)  # Cap at 1.0
    
    async def process_direct_order(self, update: Update, store: Dict, analysis, user_name: str, message_text: str):
        """Process a direct order from customer"""
        order_data = {
            'customer_name': analysis.customer_name if analysis.customer_name != "غير محدد" else user_name,
            'customer_phone': analysis.customer_phone,
            'order_details': analysis.order_details,
            'platform': 'telegram_direct',
            'created_at': 'الآن'
        }
        
        # Save order
        success = self.db.add_order(store['id'], order_data)
        
        if success:
            # Send notification to store owner
            await self.notifications.send_order_notification(
                store['telegram_id'],
                order_data,
                store['store_name']
            )
            
            # Send confirmation to customer
            await update.message.reply_text(
                f"{EMOJIS['success']} تم استلام طلبك بنجاح!\n\n"
                f"📋 تفاصيل الطلب: {order_data['order_details']}\n"
                f"🏪 المتجر: {store['store_name']}\n\n"
                f"سيتم التواصل معك قريباً عبر الرقم المسجل أو التليجرام."
            )
            
            # Send admin notification
            await self.notifications.send_admin_notification(
                ADMIN_ID,
                f"طلب جديد عبر الرسائل المباشرة!\n"
                f"العميل: {user_name}\n"
                f"المتجر: {store['store_name']}\n"
                f"الطلب: {order_data['order_details']}"
            )
        else:
            await update.message.reply_text(
                f"{EMOJIS['error']} حدث خطأ في معالجة الطلب. يرجى المحاولة مرة أخرى."
            )
    
    async def handle_no_match_found(self, update: Update, user_name: str, message_text: str):
        """Handle cases where no suitable store is found"""
        # Create keyboard with available stores
        all_stores = self.db.get_all_stores()
        keyboard = []
        
        for store in all_stores[:5]:  # Show top 5 stores
            keyboard.append([
                InlineKeyboardButton(
                    f"{EMOJIS['store']} {store['store_name']}", 
                    callback_data=f"select_store_{store['id']}"
                )
            ])
        
        keyboard.append([
            InlineKeyboardButton(f"{EMOJIS['help']} تواصل مع الإدارة", callback_data="contact_admin")
        ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            f"مرحباً {user_name}! 👋\n\n"
            f"شكراً لك على تواصلك معنا. لم أتمكن من تحديد المتجر المناسب لطلبك.\n\n"
            f"يرجى اختيار المتجر المناسب من القائمة أدناه:",
            reply_markup=reply_markup
        )
        
        # Log unmatched message for admin review
        await self.notifications.send_admin_notification(
            ADMIN_ID,
            f"رسالة غير مطابقة من {user_name}:\n{message_text}"
        )
    
    async def handle_store_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE, store_id: int):
        """Handle when customer selects a specific store"""
        query = update.callback_query
        await query.answer()
        
        user_name = update.effective_user.first_name or "العميل"
        
        # Get store information
        store = next((s for s in self.db.get_all_stores() if s['id'] == store_id), None)
        
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} المتجر غير موجود."
            )
            return
        
        # Send store information
        store_info = f"""
{EMOJIS['store']} *معلومات المتجر: {store['store_name']}*

{EMOJIS['location']} *الموقع:* {store.get('location', 'غير محدد')}

{EMOJIS['facebook']} *الفيسبوك:* {store.get('facebook_url', 'غير متوفر')}
{EMOJIS['instagram']} *الإنستقرام:* {store.get('instagram_url', 'غير متوفر')}
{EMOJIS['tiktok']} *التيك توك:* {store.get('tiktok_url', 'غير متوفر')}

يرجى كتابة طلبك أو استفسارك وسنقوم بالرد عليك قريباً.
        """
        
        await query.edit_message_text(
            store_info,
            parse_mode='Markdown'
        )
        
        # Store the selected store for this user
        context.user_data['selected_store_id'] = store_id
        
        # Notify store owner
        await self.notifications.send_store_update_notification(
            store['telegram_id'],
            store['store_name'],
            f"عميل جديد ({user_name}) اختار متجرك للتواصل"
        )