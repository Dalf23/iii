"""
Inventory Manager - مدير المخزون التلقائي
يدير المخزون تلقائياً بالذكاء الاصطناعي
"""

import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from config import *
from gemini_ai import GeminiAIManager

logger = logging.getLogger(__name__)

@dataclass
class InventoryAlert:
    """تنبيه المخزون"""
    item_id: int
    item_name: str
    alert_type: str  # 'low_stock', 'out_of_stock', 'expired', 'high_demand'
    current_quantity: int
    threshold_quantity: int
    message: str
    priority: str  # 'high', 'medium', 'low'
    created_at: datetime

@dataclass
class StockPrediction:
    """توقع المخزون"""
    item_id: int
    predicted_demand: int
    days_until_stockout: int
    recommended_reorder_quantity: int
    confidence: float
    factors: List[str]

@dataclass
class PriceOptimization:
    """تحسين السعر"""
    item_id: int
    current_price: float
    recommended_price: float
    price_change_reason: str
    expected_impact: str
    confidence: float

class InventoryManager:
    """مدير المخزون الذكي مع التحليل والتوقع"""
    
    def __init__(self, ai_manager: GeminiAIManager, db_manager):
        self.ai_manager = ai_manager
        self.db_manager = db_manager
        self.auto_management_enabled = True
        self.alert_thresholds = {
            'low_stock': 10,
            'critical_stock': 3,
            'high_demand_threshold': 50  # عدد الطلبات في الأسبوع
        }
        self.monitoring_active = False
        
    async def start_inventory_monitoring(self, store_id: int):
        """بدء مراقبة المخزون التلقائية"""
        try:
            self.monitoring_active = True
            logger.info(f"🔄 بدء مراقبة المخزون للمتجر {store_id}")
            
            while self.monitoring_active:
                await self.monitor_inventory_levels(store_id)
                await self.analyze_demand_patterns(store_id)
                await self.optimize_pricing(store_id)
                await self.generate_inventory_alerts(store_id)
                
                # انتظار قبل التحقق مرة أخرى
                await asyncio.sleep(3600)  # كل ساعة
                
        except Exception as e:
            logger.error(f"خطأ في مراقبة المخزون: {e}")
    
    async def monitor_inventory_levels(self, store_id: int):
        """مراقبة مستويات المخزون"""
        try:
            inventory = self.db_manager.get_inventory_by_store(store_id)
            
            for item in inventory:
                # تحليل مستوى المخزون
                await self.analyze_stock_level(store_id, item)
                
                # تحديث حالة المنتج
                await self.update_item_status(item)
                
        except Exception as e:
            logger.error(f"خطأ في مراقبة مستويات المخزون: {e}")
    
    async def analyze_stock_level(self, store_id: int, item: Dict):
        """تحليل مستوى المخزون للمنتج"""
        try:
            current_quantity = item.get('quantity', 0)
            item_name = item.get('name', 'منتج غير محدد')
            
            # تحليل الطلب التاريخي
            historical_demand = await self.get_historical_demand(store_id, item['id'])
            
            # تحليل الاتجاه
            trend_analysis = await self.analyze_demand_trend(historical_demand)
            
            # توقع الطلب المستقبلي
            prediction = await self.predict_future_demand(item, historical_demand, trend_analysis)
            
            # إنشاء تنبيهات إذا لزم الأمر
            if current_quantity <= self.alert_thresholds['critical_stock']:
                await self.create_stock_alert(item, 'critical_stock', 'عاجل')
            elif current_quantity <= self.alert_thresholds['low_stock']:
                await self.create_stock_alert(item, 'low_stock', 'متوسط')
            
            # توصيات إعادة الطلب
            if prediction.days_until_stockout <= 7:
                await self.create_reorder_recommendation(item, prediction)
                
        except Exception as e:
            logger.error(f"خطأ في تحليل مستوى المخزون: {e}")
    
    async def get_historical_demand(self, store_id: int, item_id: int) -> List[Dict]:
        """الحصول على البيانات التاريخية للطلب"""
        try:
            # جلب الطلبات التاريخية للمنتج
            orders = self.db_manager.get_orders_by_store(store_id)
            
            # تصفية الطلبات التي تحتوي على هذا المنتج
            item_orders = []
            for order in orders:
                if str(item_id) in order.get('order_details', ''):
                    item_orders.append({
                        'date': order.get('timestamp', datetime.now().isoformat()),
                        'quantity': 1,  # افتراضي
                        'order_id': order['id']
                    })
            
            return item_orders
            
        except Exception as e:
            logger.error(f"خطأ في جلب البيانات التاريخية: {e}")
            return []
    
    async def analyze_demand_trend(self, historical_demand: List[Dict]) -> Dict:
        """تحليل اتجاه الطلب"""
        try:
            if not historical_demand:
                return {'trend': 'stable', 'confidence': 0.5}
            
            # تجميع البيانات حسب الأسبوع
            weekly_demand = {}
            for order in historical_demand:
                order_date = datetime.fromisoformat(order['date'])
                week_key = f"{order_date.year}-{order_date.isocalendar()[1]}"
                weekly_demand[week_key] = weekly_demand.get(week_key, 0) + order['quantity']
            
            # تحليل الاتجاه
            demand_values = list(weekly_demand.values())
            if len(demand_values) >= 3:
                recent_avg = sum(demand_values[-2:]) / 2
                older_avg = sum(demand_values[:-2]) / max(1, len(demand_values) - 2)
                
                if recent_avg > older_avg * 1.2:
                    trend = 'increasing'
                elif recent_avg < older_avg * 0.8:
                    trend = 'decreasing'
                else:
                    trend = 'stable'
            else:
                trend = 'stable'
            
            return {
                'trend': trend,
                'confidence': 0.7,
                'weekly_demand': weekly_demand
            }
            
        except Exception as e:
            logger.error(f"خطأ في تحليل الاتجاه: {e}")
            return {'trend': 'stable', 'confidence': 0.5}
    
    async def predict_future_demand(self, item: Dict, historical_demand: List[Dict], trend_analysis: Dict) -> StockPrediction:
        """توقع الطلب المستقبلي"""
        try:
            current_quantity = item.get('quantity', 0)
            
            # حساب متوسط الطلب الأسبوعي
            if historical_demand:
                weekly_demand = len(historical_demand) / max(1, len(set([
                    datetime.fromisoformat(order['date']).isocalendar()[1] 
                    for order in historical_demand
                ])))
            else:
                weekly_demand = 1  # افتراضي
            
            # تعديل التوقع بناءً على الاتجاه
            if trend_analysis['trend'] == 'increasing':
                predicted_weekly_demand = weekly_demand * 1.3
            elif trend_analysis['trend'] == 'decreasing':
                predicted_weekly_demand = weekly_demand * 0.7
            else:
                predicted_weekly_demand = weekly_demand
            
            # حساب الأيام حتى نفاد المخزون
            days_until_stockout = (current_quantity / max(1, predicted_weekly_demand)) * 7
            
            # كمية إعادة الطلب المقترحة
            recommended_reorder = int(predicted_weekly_demand * 4)  # 4 أسابيع
            
            return StockPrediction(
                item_id=item['id'],
                predicted_demand=int(predicted_weekly_demand),
                days_until_stockout=int(days_until_stockout),
                recommended_reorder_quantity=recommended_reorder,
                confidence=trend_analysis['confidence'],
                factors=[f"الاتجاه: {trend_analysis['trend']}", f"الطلب الأسبوعي: {weekly_demand}"]
            )
            
        except Exception as e:
            logger.error(f"خطأ في توقع الطلب: {e}")
            return StockPrediction(
                item_id=item['id'],
                predicted_demand=1,
                days_until_stockout=30,
                recommended_reorder_quantity=10,
                confidence=0.5,
                factors=["توقع افتراضي"]
            )
    
    async def create_stock_alert(self, item: Dict, alert_type: str, priority: str):
        """إنشاء تنبيه المخزون"""
        try:
            alert_messages = {
                'critical_stock': f"🚨 مخزون حرج: {item['name']} - الكمية المتبقية: {item.get('quantity', 0)}",
                'low_stock': f"⚠️ مخزون منخفض: {item['name']} - الكمية المتبقية: {item.get('quantity', 0)}",
                'out_of_stock': f"❌ نفد المخزون: {item['name']} - يحتاج إعادة طلب فوري"
            }
            
            alert = InventoryAlert(
                item_id=item['id'],
                item_name=item['name'],
                alert_type=alert_type,
                current_quantity=item.get('quantity', 0),
                threshold_quantity=self.alert_thresholds.get(alert_type, 10),
                message=alert_messages.get(alert_type, "تنبيه مخزون"),
                priority=priority,
                created_at=datetime.now()
            )
            
            # إرسال التنبيه
            await self.send_inventory_alert(alert)
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء تنبيه المخزون: {e}")
    
    async def create_reorder_recommendation(self, item: Dict, prediction: StockPrediction):
        """إنشاء توصية إعادة الطلب"""
        try:
            # استخدام الذكاء الاصطناعي لتحسين التوصية
            prompt = f"""
            تحليل المخزون للمنتج التالي:
            
            اسم المنتج: {item['name']}
            الكمية الحالية: {item.get('quantity', 0)}
            الطلب المتوقع أسبوعياً: {prediction.predicted_demand}
            الأيام حتى نفاد المخزون: {prediction.days_until_stockout}
            
            العوامل المؤثرة:
            {', '.join(prediction.factors)}
            
            المطلوب:
            1. تقييم الوضع الحالي
            2. توصية بكمية إعادة الطلب
            3. التوقيت المناسب لإعادة الطلب
            4. أي نصائح إضافية لإدارة المخزون
            
            اكتب التوصية باللغة العربية وبشكل مفصل ومفيد.
            """
            
            ai_recommendation = await self.ai_manager.generate_content(prompt)
            
            # إرسال التوصية لصاحب المتجر
            await self.send_reorder_notification(item, prediction, ai_recommendation)
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء توصية إعادة الطلب: {e}")
    
    async def analyze_demand_patterns(self, store_id: int):
        """تحليل أنماط الطلب"""
        try:
            orders = self.db_manager.get_orders_by_store(store_id)
            
            if not orders:
                return
            
            # تحليل الأنماط الزمنية
            time_patterns = await self.analyze_time_patterns(orders)
            
            # تحليل أنماط المنتجات
            product_patterns = await self.analyze_product_patterns(orders)
            
            # تحليل أنماط العملاء
            customer_patterns = await self.analyze_customer_patterns(orders)
            
            # إنشاء تقرير الأنماط
            await self.generate_patterns_report(store_id, {
                'time_patterns': time_patterns,
                'product_patterns': product_patterns,
                'customer_patterns': customer_patterns
            })
            
        except Exception as e:
            logger.error(f"خطأ في تحليل أنماط الطلب: {e}")
    
    async def analyze_time_patterns(self, orders: List[Dict]) -> Dict:
        """تحليل الأنماط الزمنية"""
        try:
            hourly_orders = {}
            daily_orders = {}
            
            for order in orders:
                order_date = datetime.fromisoformat(order['timestamp'])
                hour = order_date.hour
                day = order_date.strftime('%A')
                
                hourly_orders[hour] = hourly_orders.get(hour, 0) + 1
                daily_orders[day] = daily_orders.get(day, 0) + 1
            
            # تحديد أفضل الأوقات
            best_hour = max(hourly_orders, key=hourly_orders.get) if hourly_orders else 20
            best_day = max(daily_orders, key=daily_orders.get) if daily_orders else 'Sunday'
            
            return {
                'best_hour': best_hour,
                'best_day': best_day,
                'hourly_distribution': hourly_orders,
                'daily_distribution': daily_orders
            }
            
        except Exception as e:
            logger.error(f"خطأ في تحليل الأنماط الزمنية: {e}")
            return {}
    
    async def analyze_product_patterns(self, orders: List[Dict]) -> Dict:
        """تحليل أنماط المنتجات"""
        try:
            product_demand = {}
            
            for order in orders:
                # استخراج المنتجات من تفاصيل الطلب
                order_details = order.get('order_details', '')
                # تحليل بسيط للمنتجات
                products = order_details.split(',')
                
                for product in products:
                    product = product.strip()
                    if product:
                        product_demand[product] = product_demand.get(product, 0) + 1
            
            # ترتيب المنتجات حسب الطلب
            sorted_products = sorted(product_demand.items(), key=lambda x: x[1], reverse=True)
            
            return {
                'top_products': sorted_products[:10],
                'total_unique_products': len(product_demand),
                'product_demand': product_demand
            }
            
        except Exception as e:
            logger.error(f"خطأ في تحليل أنماط المنتجات: {e}")
            return {}
    
    async def analyze_customer_patterns(self, orders: List[Dict]) -> Dict:
        """تحليل أنماط العملاء"""
        try:
            customer_orders = {}
            
            for order in orders:
                customer_name = order.get('customer_name', 'غير محدد')
                if customer_name != 'غير محدد':
                    customer_orders[customer_name] = customer_orders.get(customer_name, 0) + 1
            
            # تحليل العملاء
            total_customers = len(customer_orders)
            repeat_customers = len([c for c in customer_orders.values() if c > 1])
            
            return {
                'total_customers': total_customers,
                'repeat_customers': repeat_customers,
                'repeat_rate': repeat_customers / max(1, total_customers),
                'top_customers': sorted(customer_orders.items(), key=lambda x: x[1], reverse=True)[:5]
            }
            
        except Exception as e:
            logger.error(f"خطأ في تحليل أنماط العملاء: {e}")
            return {}
    
    async def optimize_pricing(self, store_id: int):
        """تحسين الأسعار بالذكاء الاصطناعي"""
        try:
            inventory = self.db_manager.get_inventory_by_store(store_id)
            orders = self.db_manager.get_orders_by_store(store_id)
            
            for item in inventory:
                optimization = await self.analyze_price_optimization(item, orders)
                
                if optimization and abs(optimization.recommended_price - optimization.current_price) > 0.1:
                    await self.send_price_optimization_suggestion(item, optimization)
                    
        except Exception as e:
            logger.error(f"خطأ في تحسين الأسعار: {e}")
    
    async def analyze_price_optimization(self, item: Dict, orders: List[Dict]) -> Optional[PriceOptimization]:
        """تحليل تحسين السعر"""
        try:
            current_price = item.get('price', 0)
            
            # تحليل الطلب عند السعر الحالي
            item_orders = [order for order in orders if str(item['id']) in order.get('order_details', '')]
            
            if not item_orders:
                return None
            
            # استخدام الذكاء الاصطناعي لتحليل السعر
            prompt = f"""
            تحليل السعر للمنتج التالي:
            
            اسم المنتج: {item['name']}
            السعر الحالي: {current_price}
            عدد الطلبات الأخيرة: {len(item_orders)}
            الكمية المتاحة: {item.get('quantity', 0)}
            
            المطلوب:
            1. تحليل السعر الحالي
            2. اقتراح سعر محسن
            3. توقع التأثير على الطلب
            4. مبرر التغيير
            
            اكتب التحليل باللغة العربية ومع أرقام محددة.
            """
            
            ai_analysis = await self.ai_manager.generate_content(prompt)
            
            # استخراج السعر المقترح من التحليل
            suggested_price = await self.extract_suggested_price(ai_analysis, current_price)
            
            if suggested_price and suggested_price != current_price:
                return PriceOptimization(
                    item_id=item['id'],
                    current_price=current_price,
                    recommended_price=suggested_price,
                    price_change_reason=ai_analysis[:200],
                    expected_impact="تحسين المبيعات والأرباح",
                    confidence=0.7
                )
            
            return None
            
        except Exception as e:
            logger.error(f"خطأ في تحليل تحسين السعر: {e}")
            return None
    
    async def extract_suggested_price(self, ai_analysis: str, current_price: float) -> Optional[float]:
        """استخراج السعر المقترح من تحليل الذكاء الاصطناعي"""
        try:
            # بحث عن الأرقام في النص
            import re
            numbers = re.findall(r'\d+\.?\d*', ai_analysis)
            
            for num_str in numbers:
                num = float(num_str)
                # التحقق من أن الرقم منطقي كسعر
                if 0.5 * current_price <= num <= 2 * current_price and num != current_price:
                    return num
            
            return None
            
        except Exception as e:
            logger.error(f"خطأ في استخراج السعر المقترح: {e}")
            return None
    
    async def send_inventory_alert(self, alert: InventoryAlert):
        """إرسال تنبيه المخزون"""
        try:
            from notifications import NotificationManager
            notification_manager = NotificationManager(BOT_TOKEN)
            
            # إرسال التنبيه للمدير
            await notification_manager.send_admin_notification(
                ADMIN_ID,
                f"تنبيه مخزون: {alert.message}"
            )
            
        except Exception as e:
            logger.error(f"خطأ في إرسال تنبيه المخزون: {e}")
    
    async def send_reorder_notification(self, item: Dict, prediction: StockPrediction, ai_recommendation: str):
        """إرسال إشعار إعادة الطلب"""
        try:
            from notifications import NotificationManager
            notification_manager = NotificationManager(BOT_TOKEN)
            
            message = f"""
📦 توصية إعادة طلب: {item['name']}

🔍 التحليل:
• الكمية الحالية: {item.get('quantity', 0)}
• الطلب المتوقع: {prediction.predicted_demand} أسبوعياً
• الأيام حتى نفاد المخزون: {prediction.days_until_stockout}

💡 توصية الذكاء الاصطناعي:
{ai_recommendation[:300]}...

📊 الكمية المقترحة: {prediction.recommended_reorder_quantity}
            """
            
            await notification_manager.send_admin_notification(ADMIN_ID, message)
            
        except Exception as e:
            logger.error(f"خطأ في إرسال إشعار إعادة الطلب: {e}")
    
    async def send_price_optimization_suggestion(self, item: Dict, optimization: PriceOptimization):
        """إرسال اقتراح تحسين السعر"""
        try:
            from notifications import NotificationManager
            notification_manager = NotificationManager(BOT_TOKEN)
            
            message = f"""
💰 اقتراح تحسين السعر: {item['name']}

السعر الحالي: {optimization.current_price}
السعر المقترح: {optimization.recommended_price}
التغيير: {optimization.recommended_price - optimization.current_price:+.2f}

📈 السبب: {optimization.price_change_reason}
📊 التأثير المتوقع: {optimization.expected_impact}
            """
            
            await notification_manager.send_admin_notification(ADMIN_ID, message)
            
        except Exception as e:
            logger.error(f"خطأ في إرسال اقتراح تحسين السعر: {e}")
    
    async def generate_patterns_report(self, store_id: int, patterns: Dict):
        """إنشاء تقرير الأنماط"""
        try:
            report = f"""
📊 تقرير أنماط الطلب - المتجر {store_id}

⏰ الأنماط الزمنية:
• أفضل ساعة للطلبات: {patterns['time_patterns'].get('best_hour', 'غير محدد')}
• أفضل يوم للطلبات: {patterns['time_patterns'].get('best_day', 'غير محدد')}

🛍️ أنماط المنتجات:
• إجمالي المنتجات المطلوبة: {patterns['product_patterns'].get('total_unique_products', 0)}
• أكثر المنتجات طلباً: {patterns['product_patterns'].get('top_products', [])[:3]}

👥 أنماط العملاء:
• إجمالي العملاء: {patterns['customer_patterns'].get('total_customers', 0)}
• العملاء المتكررون: {patterns['customer_patterns'].get('repeat_customers', 0)}
• نسبة العملاء المتكررين: {patterns['customer_patterns'].get('repeat_rate', 0):.1%}

التاريخ: {datetime.now().strftime('%Y-%m-%d %H:%M')}
            """
            
            # حفظ التقرير أو إرساله
            logger.info(f"تم إنشاء تقرير الأنماط للمتجر {store_id}")
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء تقرير الأنماط: {e}")
    
    async def update_item_status(self, item: Dict):
        """تحديث حالة المنتج"""
        try:
            current_quantity = item.get('quantity', 0)
            
            # تحديد الحالة
            if current_quantity == 0:
                status = 'out_of_stock'
            elif current_quantity <= self.alert_thresholds['critical_stock']:
                status = 'critical'
            elif current_quantity <= self.alert_thresholds['low_stock']:
                status = 'low'
            else:
                status = 'available'
            
            # تحديث في قاعدة البيانات
            # يمكن إضافة حقل status للمنتجات في قاعدة البيانات
            
        except Exception as e:
            logger.error(f"خطأ في تحديث حالة المنتج: {e}")
    
    def stop_monitoring(self):
        """إيقاف مراقبة المخزون"""
        self.monitoring_active = False
        logger.info("🛑 تم إيقاف مراقبة المخزون")
    
    def toggle_auto_management(self, enabled: bool):
        """تفعيل/إلغاء الإدارة التلقائية"""
        self.auto_management_enabled = enabled
        status = "مفعل" if enabled else "معطل"
        logger.info(f"🔄 الإدارة التلقائية للمخزون {status}")
    
    def update_alert_thresholds(self, thresholds: Dict):
        """تحديث عتبات التنبيه"""
        self.alert_thresholds.update(thresholds)
        logger.info("تم تحديث عتبات التنبيه")
    
    def get_inventory_status(self, store_id: int) -> Dict:
        """الحصول على حالة المخزون"""
        try:
            inventory = self.db_manager.get_inventory_by_store(store_id)
            
            total_items = len(inventory)
            low_stock_items = len([item for item in inventory if item.get('quantity', 0) <= self.alert_thresholds['low_stock']])
            out_of_stock_items = len([item for item in inventory if item.get('quantity', 0) == 0])
            
            return {
                'total_items': total_items,
                'low_stock_items': low_stock_items,
                'out_of_stock_items': out_of_stock_items,
                'monitoring_active': self.monitoring_active,
                'auto_management_enabled': self.auto_management_enabled
            }
            
        except Exception as e:
            logger.error(f"خطأ في الحصول على حالة المخزون: {e}")
            return {}