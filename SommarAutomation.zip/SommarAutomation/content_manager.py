"""
Content Manager - مدير المحتوى الذكي
ينتج المحتوى التلقائي للمنصات الاجتماعية باستخدام الذكاء الاصطناعي
"""

import logging
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from config import *
from gemini_ai import GeminiAIManager

logger = logging.getLogger(__name__)

@dataclass
class ContentTemplate:
    """قالب المحتوى"""
    title: str
    content: str
    platform: str
    content_type: str  # 'product', 'promo', 'story', 'ad'
    tags: List[str]
    media_type: str  # 'image', 'video', 'text'
    schedule_time: Optional[datetime] = None

@dataclass
class GeneratedContent:
    """المحتوى المولد"""
    content: str
    caption: str
    hashtags: List[str]
    platform: str
    content_type: str
    media_suggestions: List[str]
    best_post_time: str
    engagement_prediction: float

class ContentManager:
    """مدير المحتوى الذكي مع الذكاء الاصطناعي"""
    
    def __init__(self, ai_manager: GeminiAIManager, db_manager):
        self.ai_manager = ai_manager
        self.db_manager = db_manager
        self.content_templates = self.load_content_templates()
        self.posting_schedule = {}
        self.auto_posting_enabled = True
        
    def load_content_templates(self) -> Dict[str, List[ContentTemplate]]:
        """تحميل قوالب المحتوى"""
        return {
            'product': [
                ContentTemplate(
                    title="منتج جديد",
                    content="🆕 منتج جديد وصل حديثاً! {product_name}\n\n✨ المميزات:\n{features}\n\n💰 السعر: {price}\n\n📞 للطلب: {contact}",
                    platform="all",
                    content_type="product",
                    tags=["منتج_جديد", "عرض", "تسوق"],
                    media_type="image"
                ),
                ContentTemplate(
                    title="عرض خاص",
                    content="🔥 عرض خاص لفترة محدودة!\n\n{product_name}\n\n💥 خصم {discount}%\n\n⏰ العرض حتى: {end_date}\n\n🛒 اطلب الآن: {contact}",
                    platform="all",
                    content_type="promo",
                    tags=["عرض_خاص", "خصم", "تخفيض"],
                    media_type="image"
                )
            ],
            'story': [
                ContentTemplate(
                    title="قصة نجاح",
                    content="💫 قصة نجاح من عملائنا الأعزاء\n\n{customer_story}\n\n🙏 شكراً لثقتكم بنا",
                    platform="all",
                    content_type="story",
                    tags=["قصة_نجاح", "عملاء", "شكر"],
                    media_type="image"
                )
            ],
            'engagement': [
                ContentTemplate(
                    title="سؤال تفاعلي",
                    content="🤔 {question}\n\n📝 شاركونا آرائكم في التعليقات\n\n👍 اعجبوا إذا أعجبكم المنشور",
                    platform="all",
                    content_type="engagement",
                    tags=["تفاعل", "سؤال", "رأي"],
                    media_type="text"
                )
            ]
        }
    
    async def generate_daily_content(self, store: Dict) -> List[GeneratedContent]:
        """إنتاج محتوى يومي للمتجر"""
        try:
            daily_content = []
            
            # الحصول على معلومات المتجر والمنتجات
            inventory = self.db_manager.get_inventory_by_store(store['id'])
            recent_orders = self.db_manager.get_orders_by_store(store['id'])
            
            # إنتاج محتوى متنوع
            content_types = ['product', 'promo', 'story', 'engagement']
            
            for content_type in content_types:
                if content_type == 'product' and inventory:
                    # محتوى المنتجات
                    product_content = await self.generate_product_content(store, inventory)
                    daily_content.extend(product_content)
                
                elif content_type == 'promo':
                    # محتوى العروض
                    promo_content = await self.generate_promotional_content(store, inventory)
                    daily_content.extend(promo_content)
                
                elif content_type == 'story' and recent_orders:
                    # قصص النجاح
                    story_content = await self.generate_success_stories(store, recent_orders)
                    daily_content.extend(story_content)
                
                elif content_type == 'engagement':
                    # محتوى التفاعل
                    engagement_content = await self.generate_engagement_content(store)
                    daily_content.extend(engagement_content)
            
            return daily_content
            
        except Exception as e:
            logger.error(f"خطأ في إنتاج المحتوى اليومي: {e}")
            return []
    
    async def generate_product_content(self, store: Dict, inventory: List[Dict]) -> List[GeneratedContent]:
        """إنتاج محتوى المنتجات"""
        try:
            product_content = []
            
            # اختيار منتجات للترويج
            featured_products = inventory[:3]  # أول 3 منتجات
            
            for product in featured_products:
                # استخدام الذكاء الاصطناعي لإنتاج وصف جذاب
                prompt = f"""
                أنتج محتوى تسويقي جذاب للمنتج التالي:
                
                اسم المنتج: {product['name']}
                الوصف: {product.get('description', 'لا يوجد وصف')}
                السعر: {product.get('price', 'السعر عند الطلب')}
                الكمية المتاحة: {product.get('quantity', 'متوفر')}
                
                اسم المتجر: {store['name']}
                
                المطلوب:
                1. عنوان جذاب
                2. وصف تسويقي مقنع
                3. دعوة للعمل قوية
                4. هاشتاجات مناسبة
                
                اكتب المحتوى باللغة العربية وبأسلوب جذاب ومقنع.
                """
                
                ai_response = await self.ai_manager.generate_content(prompt)
                
                # تحليل استجابة الذكاء الاصطناعي
                content_parts = self.parse_ai_content_response(ai_response)
                
                # إنشاء محتوى لكل منصة
                for platform in ['facebook', 'instagram', 'tiktok']:
                    customized_content = self.customize_content_for_platform(
                        content_parts, 
                        platform, 
                        store
                    )
                    
                    generated_content = GeneratedContent(
                        content=customized_content['content'],
                        caption=customized_content['caption'],
                        hashtags=customized_content['hashtags'],
                        platform=platform,
                        content_type='product',
                        media_suggestions=self.suggest_media_for_product(product),
                        best_post_time=self.calculate_best_post_time(platform),
                        engagement_prediction=self.predict_engagement(customized_content, platform)
                    )
                    
                    product_content.append(generated_content)
            
            return product_content
            
        except Exception as e:
            logger.error(f"خطأ في إنتاج محتوى المنتجات: {e}")
            return []
    
    async def generate_promotional_content(self, store: Dict, inventory: List[Dict]) -> List[GeneratedContent]:
        """إنتاج محتوى العروض والخصومات"""
        try:
            promo_content = []
            
            # إنشاء عروض ذكية
            promo_ideas = [
                "عرض خصم 20% لأول 10 عملاء",
                "اشتر 2 واحصل على 1 مجاناً",
                "عرض نهاية الأسبوع الخاص",
                "خصم للعملاء الجدد"
            ]
            
            for promo_idea in promo_ideas[:2]:  # عرضين فقط
                prompt = f"""
                أنتج محتوى تسويقي لعرض خاص:
                
                فكرة العرض: {promo_idea}
                اسم المتجر: {store['name']}
                المنتجات المتاحة: {', '.join([p['name'] for p in inventory[:5]])}
                
                المطلوب:
                1. عنوان جذاب للعرض
                2. تفاصيل العرض بشكل مقنع
                3. شروط العرض
                4. دعوة للعمل عاجلة
                5. هاشتاجات مناسبة
                
                اكتب المحتوى باللغة العربية وبأسلوب يحفز على الشراء.
                """
                
                ai_response = await self.ai_manager.generate_content(prompt)
                content_parts = self.parse_ai_content_response(ai_response)
                
                # إنشاء محتوى لكل منصة
                for platform in ['facebook', 'instagram', 'tiktok']:
                    customized_content = self.customize_content_for_platform(
                        content_parts, 
                        platform, 
                        store
                    )
                    
                    generated_content = GeneratedContent(
                        content=customized_content['content'],
                        caption=customized_content['caption'],
                        hashtags=customized_content['hashtags'],
                        platform=platform,
                        content_type='promo',
                        media_suggestions=self.suggest_media_for_promo(promo_idea),
                        best_post_time=self.calculate_best_post_time(platform),
                        engagement_prediction=self.predict_engagement(customized_content, platform)
                    )
                    
                    promo_content.append(generated_content)
            
            return promo_content
            
        except Exception as e:
            logger.error(f"خطأ في إنتاج محتوى العروض: {e}")
            return []
    
    async def generate_success_stories(self, store: Dict, recent_orders: List[Dict]) -> List[GeneratedContent]:
        """إنتاج قصص نجاح العملاء"""
        try:
            story_content = []
            
            # اختيار طلبات مكتملة للقصص
            completed_orders = [order for order in recent_orders if order['status'] == 'completed']
            
            if not completed_orders:
                return []
            
            # إنشاء قصة نجاح
            sample_order = completed_orders[0]
            
            prompt = f"""
            أنتج قصة نجاح للعميل بناءً على هذه المعلومات:
            
            تفاصيل الطلب: {sample_order['order_details']}
            اسم المتجر: {store['name']}
            
            المطلوب:
            1. قصة نجاح ملهمة (بدون ذكر أسماء حقيقية)
            2. التركيز على جودة المنتج/الخدمة
            3. رسالة شكر للعملاء
            4. دعوة للعملاء الجدد
            
            اكتب القصة باللغة العربية وبأسلوب مؤثر وملهم.
            """
            
            ai_response = await self.ai_manager.generate_content(prompt)
            content_parts = self.parse_ai_content_response(ai_response)
            
            # إنشاء محتوى لكل منصة
            for platform in ['facebook', 'instagram', 'tiktok']:
                customized_content = self.customize_content_for_platform(
                    content_parts, 
                    platform, 
                    store
                )
                
                generated_content = GeneratedContent(
                    content=customized_content['content'],
                    caption=customized_content['caption'],
                    hashtags=customized_content['hashtags'],
                    platform=platform,
                    content_type='story',
                    media_suggestions=self.suggest_media_for_story(),
                    best_post_time=self.calculate_best_post_time(platform),
                    engagement_prediction=self.predict_engagement(customized_content, platform)
                )
                
                story_content.append(generated_content)
            
            return story_content
            
        except Exception as e:
            logger.error(f"خطأ في إنتاج قصص النجاح: {e}")
            return []
    
    async def generate_engagement_content(self, store: Dict) -> List[GeneratedContent]:
        """إنتاج محتوى التفاعل"""
        try:
            engagement_content = []
            
            # أفكار المحتوى التفاعلي
            engagement_ideas = [
                "ما هو المنتج المفضل لديكم؟",
                "شاركونا تجربتكم مع منتجاتنا",
                "أي خدمة تودون أن نضيفها؟",
                "ما رأيكم في آخر منتجاتنا؟"
            ]
            
            selected_idea = engagement_ideas[0]  # اختيار الفكرة الأولى
            
            prompt = f"""
            أنتج محتوى تفاعلي جذاب:
            
            فكرة المحتوى: {selected_idea}
            اسم المتجر: {store['name']}
            
            المطلوب:
            1. سؤال تفاعلي جذاب
            2. دعوة للتفاعل في التعليقات
            3. محتوى يشجع على المشاركة
            4. هاشتاجات مناسبة
            
            اكتب المحتوى باللغة العربية وبأسلوب ودود ومحفز للتفاعل.
            """
            
            ai_response = await self.ai_manager.generate_content(prompt)
            content_parts = self.parse_ai_content_response(ai_response)
            
            # إنشاء محتوى لكل منصة
            for platform in ['facebook', 'instagram', 'tiktok']:
                customized_content = self.customize_content_for_platform(
                    content_parts, 
                    platform, 
                    store
                )
                
                generated_content = GeneratedContent(
                    content=customized_content['content'],
                    caption=customized_content['caption'],
                    hashtags=customized_content['hashtags'],
                    platform=platform,
                    content_type='engagement',
                    media_suggestions=self.suggest_media_for_engagement(),
                    best_post_time=self.calculate_best_post_time(platform),
                    engagement_prediction=self.predict_engagement(customized_content, platform)
                )
                
                engagement_content.append(generated_content)
            
            return engagement_content
            
        except Exception as e:
            logger.error(f"خطأ في إنتاج محتوى التفاعل: {e}")
            return []
    
    def parse_ai_content_response(self, ai_response: str) -> Dict:
        """تحليل استجابة الذكاء الاصطناعي"""
        try:
            # تحليل بسيط للمحتوى
            lines = ai_response.split('\n')
            
            content_parts = {
                'title': '',
                'content': ai_response,
                'hashtags': []
            }
            
            # استخراج الهاشتاجات
            hashtags = []
            for line in lines:
                if '#' in line:
                    tags = [tag.strip() for tag in line.split('#')[1:]]
                    hashtags.extend([f"#{tag}" for tag in tags if tag])
            
            content_parts['hashtags'] = hashtags[:10]  # أول 10 هاشتاجات
            
            return content_parts
            
        except Exception as e:
            logger.error(f"خطأ في تحليل استجابة الذكاء الاصطناعي: {e}")
            return {
                'title': '',
                'content': ai_response,
                'hashtags': []
            }
    
    def customize_content_for_platform(self, content_parts: Dict, platform: str, store: Dict) -> Dict:
        """تخصيص المحتوى لكل منصة"""
        try:
            base_content = content_parts['content']
            base_hashtags = content_parts['hashtags']
            
            if platform == 'facebook':
                # محتوى Facebook - مفصل أكثر
                content = f"{base_content}\n\n📧 للتواصل: {store.get('contact_info', 'رسالة خاصة')}"
                caption = base_content
                hashtags = base_hashtags + ['#فيسبوك', '#تسوق_اونلاين']
                
            elif platform == 'instagram':
                # محتوى Instagram - بصري أكثر
                content = f"{base_content}\n\n📸 تابعونا لمزيد من المحتوى الحصري"
                caption = base_content
                hashtags = base_hashtags + ['#انستقرام', '#تسوق', '#موضة']
                
            elif platform == 'tiktok':
                # محتوى TikTok - مختصر وجذاب
                content = f"{base_content}\n\n🎵 شاركوا الفيديو مع أصدقائكم"
                caption = base_content
                hashtags = base_hashtags + ['#تيك_توك', '#ترند', '#فيديو']
                
            else:
                content = base_content
                caption = base_content
                hashtags = base_hashtags
            
            return {
                'content': content,
                'caption': caption,
                'hashtags': hashtags[:15]  # الحد الأقصى للهاشتاجات
            }
            
        except Exception as e:
            logger.error(f"خطأ في تخصيص المحتوى: {e}")
            return {
                'content': content_parts['content'],
                'caption': content_parts['content'],
                'hashtags': content_parts['hashtags']
            }
    
    def suggest_media_for_product(self, product: Dict) -> List[str]:
        """اقتراح وسائط للمنتج"""
        return [
            f"صورة المنتج: {product['name']}",
            f"فيديو توضيحي للمنتج",
            f"صور متعددة للمنتج من زوايا مختلفة",
            f"انفوجرافيك بمميزات المنتج"
        ]
    
    def suggest_media_for_promo(self, promo_idea: str) -> List[str]:
        """اقتراح وسائط للعروض"""
        return [
            f"بانر العرض: {promo_idea}",
            f"فيديو قصير للعرض",
            f"صورة العد التنازلي للعرض",
            f"انفوجرافيك بتفاصيل العرض"
        ]
    
    def suggest_media_for_story(self) -> List[str]:
        """اقتراح وسائط للقصص"""
        return [
            "صورة العميل السعيد (بإذن)",
            "صورة المنتج",
            "فيديو شكر قصير",
            "انفوجرافيك بالإحصائيات"
        ]
    
    def suggest_media_for_engagement(self) -> List[str]:
        """اقتراح وسائط للتفاعل"""
        return [
            "صورة سؤال تفاعلي",
            "فيديو قصير بالسؤال",
            "استطلاع رأي",
            "صورة مع نص السؤال"
        ]
    
    def calculate_best_post_time(self, platform: str) -> str:
        """حساب أفضل وقت للنشر"""
        best_times = {
            'facebook': '19:00-21:00',
            'instagram': '20:00-22:00',
            'tiktok': '18:00-20:00'
        }
        return best_times.get(platform, '20:00-21:00')
    
    def predict_engagement(self, content: Dict, platform: str) -> float:
        """توقع نسبة التفاعل"""
        try:
            # توقع بسيط بناءً على المحتوى
            base_score = 0.5
            
            # زيادة النقاط بناءً على المحتوى
            if '#' in content['content']:
                base_score += 0.1
            if '🔥' in content['content'] or '💥' in content['content']:
                base_score += 0.1
            if 'خصم' in content['content'] or 'عرض' in content['content']:
                base_score += 0.2
            if len(content['hashtags']) > 5:
                base_score += 0.1
            
            # تعديل بناءً على المنصة
            platform_multiplier = {
                'facebook': 1.0,
                'instagram': 1.2,
                'tiktok': 1.5
            }
            
            final_score = base_score * platform_multiplier.get(platform, 1.0)
            return min(final_score, 1.0)  # الحد الأقصى 1.0
            
        except Exception as e:
            logger.error(f"خطأ في توقع التفاعل: {e}")
            return 0.5
    
    async def schedule_content(self, content: GeneratedContent, schedule_time: datetime):
        """جدولة المحتوى للنشر"""
        try:
            # إضافة المحتوى لجدولة النشر
            if content.platform not in self.posting_schedule:
                self.posting_schedule[content.platform] = []
            
            self.posting_schedule[content.platform].append({
                'content': content,
                'schedule_time': schedule_time,
                'status': 'scheduled'
            })
            
            logger.info(f"تم جدولة المحتوى للنشر في {schedule_time}")
            return True
            
        except Exception as e:
            logger.error(f"خطأ في جدولة المحتوى: {e}")
            return False
    
    async def auto_post_scheduled_content(self):
        """نشر المحتوى المجدول تلقائياً"""
        try:
            if not self.auto_posting_enabled:
                return
            
            current_time = datetime.now()
            
            for platform, scheduled_posts in self.posting_schedule.items():
                for post_data in scheduled_posts:
                    if (post_data['status'] == 'scheduled' and 
                        post_data['schedule_time'] <= current_time):
                        
                        # نشر المحتوى
                        success = await self.post_content_to_platform(
                            post_data['content'], 
                            platform
                        )
                        
                        if success:
                            post_data['status'] = 'posted'
                            logger.info(f"تم نشر المحتوى على {platform}")
                        else:
                            post_data['status'] = 'failed'
                            logger.error(f"فشل نشر المحتوى على {platform}")
            
        except Exception as e:
            logger.error(f"خطأ في النشر التلقائي: {e}")
    
    async def post_content_to_platform(self, content: GeneratedContent, platform: str) -> bool:
        """نشر المحتوى على المنصة"""
        try:
            # هذه الدالة تحتاج API tokens للمنصات
            # يمكن تطويرها مع الحصول على الصلاحيات المناسبة
            
            if platform == 'facebook':
                return await self.post_to_facebook(content)
            elif platform == 'instagram':
                return await self.post_to_instagram(content)
            elif platform == 'tiktok':
                return await self.post_to_tiktok(content)
            
            return False
            
        except Exception as e:
            logger.error(f"خطأ في نشر المحتوى: {e}")
            return False
    
    async def post_to_facebook(self, content: GeneratedContent) -> bool:
        """نشر على Facebook"""
        try:
            # نشر باستخدام Facebook Graph API
            # يحتاج Facebook Page Access Token
            logger.info(f"نشر محتوى على Facebook: {content.content[:50]}...")
            return True
        except Exception as e:
            logger.error(f"خطأ في نشر على Facebook: {e}")
            return False
    
    async def post_to_instagram(self, content: GeneratedContent) -> bool:
        """نشر على Instagram"""
        try:
            # نشر باستخدام Instagram Basic Display API
            # يحتاج Instagram Access Token
            logger.info(f"نشر محتوى على Instagram: {content.content[:50]}...")
            return True
        except Exception as e:
            logger.error(f"خطأ في نشر على Instagram: {e}")
            return False
    
    async def post_to_tiktok(self, content: GeneratedContent) -> bool:
        """نشر على TikTok"""
        try:
            # نشر باستخدام TikTok API
            # يحتاج TikTok Access Token
            logger.info(f"نشر محتوى على TikTok: {content.content[:50]}...")
            return True
        except Exception as e:
            logger.error(f"خطأ في نشر على TikTok: {e}")
            return False
    
    def get_content_analytics(self, store_id: int) -> Dict:
        """الحصول على إحصائيات المحتوى"""
        try:
            # إحصائيات المحتوى المولد والمنشور
            return {
                'total_content_generated': len(self.posting_schedule),
                'content_posted_today': 0,
                'engagement_rate': 0.75,
                'best_performing_platform': 'instagram',
                'content_types': ['product', 'promo', 'story', 'engagement']
            }
        except Exception as e:
            logger.error(f"خطأ في الحصول على الإحصائيات: {e}")
            return {}
    
    def toggle_auto_posting(self, enabled: bool):
        """تفعيل/إلغاء النشر التلقائي"""
        self.auto_posting_enabled = enabled
        status = "مفعل" if enabled else "معطل"
        logger.info(f"🔄 النشر التلقائي {status}")
    
    def clear_schedule(self, platform: str = None):
        """مسح جدولة المحتوى"""
        if platform:
            self.posting_schedule[platform] = []
        else:
            self.posting_schedule.clear()
        logger.info("تم مسح جدولة المحتوى")