import logging
import asyncio
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ConversationHandler
from telegram.error import TelegramError

# Import our modules
from config import *
from database import DatabaseManager
from gemini_ai import GeminiAIManager
from notifications import NotificationManager
from handlers import BotHandlers

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main():
    """Main function to run the bot"""
    
    # Validate configuration
    if not BOT_TOKEN or BOT_TOKEN == "your_bot_token_here":
        logger.error("Bot token not configured. Please set BOT_TOKEN environment variable.")
        return
    
    if not GEMINI_API_KEY or GEMINI_API_KEY == "your_gemini_api_key_here":
        logger.error("Gemini API key not configured. Please set GEMINI_API_KEY environment variable.")
        return
    
    if ADMIN_ID == 0:
        logger.error("Admin ID not configured. Please set ADMIN_ID environment variable.")
        return
    
    try:
        # Initialize managers
        db_manager = DatabaseManager(DATABASE_PATH)
        ai_manager = GeminiAIManager(GEMINI_API_KEY)
        notification_manager = NotificationManager(BOT_TOKEN)
        
        # Initialize bot handlers
        bot_handlers = BotHandlers(db_manager, ai_manager, notification_manager)
        
        # Create application
        application = Application.builder().token(BOT_TOKEN).build()
        
        # Set up conversation handler for store registration
        store_conv_handler = ConversationHandler(
            entry_points=[
                CallbackQueryHandler(bot_handlers.start_store_registration, pattern="^(add_store|update_store)$")
            ],
            states={
                STORE_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.collect_store_name)],
                STORE_FACEBOOK: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.collect_facebook_url)],
                STORE_TIKTOK: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.collect_tiktok_url)],
                STORE_INSTAGRAM: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.collect_instagram_url)],
                STORE_TELEGRAM: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.collect_telegram_id)],
                STORE_LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.collect_location)],
                CONFIRMATION: [CallbackQueryHandler(bot_handlers.confirm_store_data, pattern="^(confirm_store|cancel_store)$")]
            },
            fallbacks=[CommandHandler("cancel", bot_handlers.cancel)]
        )
        
        # Add handlers
        application.add_handler(CommandHandler("start", bot_handlers.start))
        application.add_handler(store_conv_handler)
        application.add_handler(CallbackQueryHandler(bot_handlers.button_handler))
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.handle_message))
        
        # Log bot startup
        logger.info("🤖 سومر أتمتة AI بوت بدأ العمل بنجاح!")
        logger.info(f"Admin ID: {ADMIN_ID}")
        logger.info(f"Database: {DATABASE_PATH}")
        
        # Start the bot
        application.run_polling(allowed_updates=["message", "callback_query"])
        
    except Exception as e:
        logger.error(f"Error starting bot: {e}")
        raise

if __name__ == "__main__":
    main()
