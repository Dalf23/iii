import logging
from typing import List, Dict, Any, Optional
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from config import EMOJIS

logger = logging.getLogger(__name__)

class UIManager:
    """Manages UI components and navigation for the Telegram bot"""
    
    @staticmethod
    def create_main_menu(is_admin: bool = False, has_store: bool = False) -> InlineKeyboardMarkup:
        """Create the main menu with navigation"""
        keyboard = []
        
        if is_admin:
            keyboard.append([
                InlineKeyboardButton(f"{EMOJIS['admin']} لوحة تحكم الإدارة", callback_data="admin_panel")
            ])
        
        if has_store:
            keyboard.extend([
                [
                    InlineKeyboardButton(f"{EMOJIS['orders']} الطلبات", callback_data="view_orders"),
                    InlineKeyboardButton(f"{EMOJIS['inventory']} المخزون", callback_data="manage_inventory")
                ],
                [
                    InlineKeyboardButton(f"{EMOJIS['store']} تحديث المتجر", callback_data="update_store"),
                    InlineKeyboardButton(f"{EMOJIS['help']} المساعدة", callback_data="help")
                ]
            ])
        else:
            keyboard.extend([
                [InlineKeyboardButton(f"{EMOJIS['store']} إضافة متجر", callback_data="add_store")],
                [InlineKeyboardButton(f"{EMOJIS['help']} المساعدة", callback_data="help")]
            ])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_back_button(callback_data: str = "back_to_main") -> List[List[InlineKeyboardButton]]:
        """Create a back button"""
        return [[InlineKeyboardButton(f"🔙 رجوع", callback_data=callback_data)]]
    
    @staticmethod
    def create_navigation_menu(current_section: str) -> List[List[InlineKeyboardButton]]:
        """Create navigation menu based on current section"""
        nav_buttons = []
        
        if current_section == "orders":
            nav_buttons = [
                [
                    InlineKeyboardButton(f"{EMOJIS['inventory']} المخزون", callback_data="manage_inventory"),
                    InlineKeyboardButton(f"{EMOJIS['store']} المتجر", callback_data="update_store")
                ]
            ]
        elif current_section == "inventory":
            nav_buttons = [
                [
                    InlineKeyboardButton(f"{EMOJIS['orders']} الطلبات", callback_data="view_orders"),
                    InlineKeyboardButton(f"{EMOJIS['store']} المتجر", callback_data="update_store")
                ]
            ]
        elif current_section == "store":
            nav_buttons = [
                [
                    InlineKeyboardButton(f"{EMOJIS['orders']} الطلبات", callback_data="view_orders"),
                    InlineKeyboardButton(f"{EMOJIS['inventory']} المخزون", callback_data="manage_inventory")
                ]
            ]
        elif current_section == "admin":
            nav_buttons = [
                [
                    InlineKeyboardButton(f"{EMOJIS['store']} عرض المتاجر", callback_data="admin_view_stores"),
                    InlineKeyboardButton(f"📊 الإحصائيات", callback_data="admin_stats")
                ]
            ]
        
        # Add back button
        nav_buttons.extend(UIManager.create_back_button())
        return nav_buttons
    
    @staticmethod
    def create_inventory_menu() -> InlineKeyboardMarkup:
        """Create inventory management menu"""
        keyboard = [
            [
                InlineKeyboardButton(f"📦 عرض المخزون", callback_data="inventory_view"),
                InlineKeyboardButton(f"➕ إضافة منتج", callback_data="inventory_add")
            ],
            [
                InlineKeyboardButton(f"🔄 تحديث منتج", callback_data="inventory_update"),
                InlineKeyboardButton(f"🗑️ حذف منتج", callback_data="inventory_delete")
            ]
        ]
        
        # Add navigation
        keyboard.extend(UIManager.create_navigation_menu("inventory"))
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_admin_menu(stores_count: int) -> InlineKeyboardMarkup:
        """Create admin panel menu"""
        keyboard = [
            [
                InlineKeyboardButton(f"👥 المتاجر ({stores_count})", callback_data="admin_view_stores"),
                InlineKeyboardButton(f"📊 الإحصائيات", callback_data="admin_stats")
            ],
            [
                InlineKeyboardButton(f"🗑️ حذف متجر", callback_data="admin_delete_store"),
                InlineKeyboardButton(f"📝 سجل الرسائل", callback_data="admin_messages_log")
            ],
            [
                InlineKeyboardButton(f"🔧 إعدادات النظام", callback_data="admin_settings"),
                InlineKeyboardButton(f"📤 تصدير البيانات", callback_data="admin_export")
            ]
        ]
        
        # Add back button
        keyboard.extend(UIManager.create_back_button())
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_orders_menu() -> InlineKeyboardMarkup:
        """Create orders management menu"""
        keyboard = [
            [
                InlineKeyboardButton(f"📋 الطلبات الحالية", callback_data="orders_current"),
                InlineKeyboardButton(f"✅ الطلبات المكتملة", callback_data="orders_completed")
            ],
            [
                InlineKeyboardButton(f"⏳ الطلبات المعلقة", callback_data="orders_pending"),
                InlineKeyboardButton(f"🔍 البحث في الطلبات", callback_data="orders_search")
            ]
        ]
        
        # Add navigation
        keyboard.extend(UIManager.create_navigation_menu("orders"))
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_store_selection_menu(stores: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
        """Create store selection menu for customers"""
        keyboard = []
        
        for store in stores[:8]:  # Show max 8 stores
            keyboard.append([
                InlineKeyboardButton(
                    f"{EMOJIS['store']} {store['store_name']}", 
                    callback_data=f"select_store_{store['id']}"
                )
            ])
        
        keyboard.append([
            InlineKeyboardButton(f"{EMOJIS['help']} تواصل مع الإدارة", callback_data="contact_admin")
        ])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_confirmation_menu(confirm_data: str, cancel_data: str = "cancel") -> InlineKeyboardMarkup:
        """Create confirmation menu"""
        keyboard = [
            [
                InlineKeyboardButton(f"{EMOJIS['success']} تأكيد", callback_data=confirm_data),
                InlineKeyboardButton(f"{EMOJIS['error']} إلغاء", callback_data=cancel_data)
            ]
        ]
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_pagination_menu(current_page: int, total_pages: int, base_callback: str) -> List[List[InlineKeyboardButton]]:
        """Create pagination buttons"""
        pagination = []
        
        if total_pages > 1:
            nav_row = []
            
            if current_page > 1:
                nav_row.append(InlineKeyboardButton("⬅️ السابق", callback_data=f"{base_callback}_page_{current_page-1}"))
            
            nav_row.append(InlineKeyboardButton(f"📄 {current_page}/{total_pages}", callback_data="page_info"))
            
            if current_page < total_pages:
                nav_row.append(InlineKeyboardButton("➡️ التالي", callback_data=f"{base_callback}_page_{current_page+1}"))
            
            pagination.append(nav_row)
        
        return pagination
    
    @staticmethod
    def create_store_info_menu(store_id: int) -> InlineKeyboardMarkup:
        """Create store information menu"""
        keyboard = [
            [
                InlineKeyboardButton(f"📋 الطلبات", callback_data=f"store_orders_{store_id}"),
                InlineKeyboardButton(f"📦 المخزون", callback_data=f"store_inventory_{store_id}")
            ],
            [
                InlineKeyboardButton(f"✏️ تعديل", callback_data=f"store_edit_{store_id}"),
                InlineKeyboardButton(f"🗑️ حذف", callback_data=f"store_delete_{store_id}")
            ]
        ]
        
        # Add back button
        keyboard.extend(UIManager.create_back_button("admin_view_stores"))
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def add_navigation_to_message(message: str, section: str, additional_info: str = "") -> str:
        """Add navigation hints to message"""
        nav_text = f"\n\n{'='*30}\n"
        
        if section == "orders":
            nav_text += f"{EMOJIS['info']} استخدم الأزرار أدناه للتنقل بين الأقسام"
        elif section == "inventory":
            nav_text += f"{EMOJIS['info']} يمكنك إدارة المخزون من الأزرار أدناه"
        elif section == "admin":
            nav_text += f"{EMOJIS['admin']} لوحة تحكم الإدارة - اختر العملية المطلوبة"
        
        if additional_info:
            nav_text += f"\n💡 {additional_info}"
        
        return message + nav_text
    
    @staticmethod
    def format_store_list(stores: List[Dict[str, Any]], page: int = 1, per_page: int = 5) -> tuple:
        """Format stores list with pagination"""
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        page_stores = stores[start_idx:end_idx]
        total_pages = (len(stores) + per_page - 1) // per_page
        
        message = f"{EMOJIS['store']} *قائمة المتاجر (صفحة {page} من {total_pages}):*\n\n"
        
        for i, store in enumerate(page_stores, start=start_idx + 1):
            message += f"""
{i}. *{store['store_name']}*
📍 الموقع: {store.get('location', 'غير محدد')}
📱 التليجرام: {store.get('telegram_id')}
📅 تاريخ التسجيل: {store.get('created_at', 'غير محدد')[:10]}
---
            """
        
        return message, total_pages
    
    @staticmethod
    def format_orders_list(orders: List[Dict[str, Any]], page: int = 1, per_page: int = 3) -> tuple:
        """Format orders list with pagination"""
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        page_orders = orders[start_idx:end_idx]
        total_pages = (len(orders) + per_page - 1) // per_page
        
        message = f"{EMOJIS['orders']} *قائمة الطلبات (صفحة {page} من {total_pages}):*\n\n"
        
        for order in page_orders:
            status_emoji = "✅" if order['status'] == 'completed' else "⏳" if order['status'] == 'pending' else "📋"
            message += f"""
{status_emoji} *طلب رقم {order['id']}*
👤 العميل: {order.get('customer_name', 'غير محدد')}
📱 الهاتف: {order.get('customer_phone', 'غير محدد')}
📝 التفاصيل: {order['order_details'][:50]}...
🌐 المنصة: {order['platform']}
📅 التاريخ: {order.get('created_at', 'غير محدد')[:16]}
📊 الحالة: {order['status']}
---
            """
        
        return message, total_pages
    
    @staticmethod
    def create_ai_automation_menu() -> InlineKeyboardMarkup:
        """Create AI automation control menu"""
        keyboard = [
            [
                InlineKeyboardButton("🔄 بدء مراقبة الصفحات", callback_data="start_monitoring"),
                InlineKeyboardButton("🛑 إيقاف المراقبة", callback_data="stop_monitoring")
            ],
            [
                InlineKeyboardButton("📝 إنتاج محتوى يومي", callback_data="generate_daily_content"),
                InlineKeyboardButton("📊 تحليل المخزون", callback_data="analyze_inventory")
            ],
            [
                InlineKeyboardButton("🤖 إعدادات الذكاء الاصطناعي", callback_data="ai_settings"),
                InlineKeyboardButton("📈 تقارير الأداء", callback_data="performance_reports")
            ],
            [InlineKeyboardButton("🔙 رجوع للقائمة الرئيسية", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_social_media_menu() -> InlineKeyboardMarkup:
        """Create social media management menu"""
        keyboard = [
            [
                InlineKeyboardButton("📘 Facebook", callback_data="manage_facebook"),
                InlineKeyboardButton("📸 Instagram", callback_data="manage_instagram")
            ],
            [
                InlineKeyboardButton("🎵 TikTok", callback_data="manage_tiktok"),
                InlineKeyboardButton("📊 إحصائيات المنصات", callback_data="platform_stats")
            ],
            [
                InlineKeyboardButton("🔗 ربط حسابات جديدة", callback_data="link_accounts"),
                InlineKeyboardButton("⚙️ إعدادات الردود", callback_data="reply_settings")
            ],
            [InlineKeyboardButton("🔙 رجوع للقائمة الرئيسية", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_content_management_menu() -> InlineKeyboardMarkup:
        """Create content management menu"""
        keyboard = [
            [
                InlineKeyboardButton("📝 إنتاج محتوى جديد", callback_data="create_content"),
                InlineKeyboardButton("📅 جدولة المحتوى", callback_data="schedule_content")
            ],
            [
                InlineKeyboardButton("📊 أداء المحتوى", callback_data="content_performance"),
                InlineKeyboardButton("🎨 قوالب المحتوى", callback_data="content_templates")
            ],
            [
                InlineKeyboardButton("🔄 النشر التلقائي", callback_data="auto_posting"),
                InlineKeyboardButton("📈 تحليل التفاعل", callback_data="engagement_analysis")
            ],
            [InlineKeyboardButton("🔙 رجوع للقائمة الرئيسية", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)