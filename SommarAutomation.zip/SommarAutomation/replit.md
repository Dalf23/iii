# Telegram Store Management Bot

## Overview

This is a Telegram bot designed to help store owners manage their businesses by automatically detecting and processing orders from various social media platforms. The bot uses AI (Google Gemini) to analyze messages and extract order information, then notifies store owners about new orders.

## System Architecture

### Backend Architecture
- **Python-based Telegram bot** using the `python-telegram-bot` library
- **SQLite database** for local data storage
- **Google Gemini AI** integration for intelligent message analysis
- **Modular design** with separate managers for different functionalities

### Key Design Decisions
- **SQLite over PostgreSQL**: Chosen for simplicity and ease of deployment for small to medium-scale operations
- **Google Gemini AI**: Selected for Arabic language support and order detection capabilities
- **Conversation-based UI**: Uses Telegram's inline keyboards for intuitive user interaction
- **Admin-controlled system**: Single admin can manage multiple stores

## Key Components

### 1. Configuration Management (`config.py`)
- Centralizes all configuration settings
- Manages environment variables for API keys and tokens
- Defines conversation states and UI emojis
- **Problem addressed**: Secure configuration management
- **Solution**: Environment variable-based configuration with fallback defaults

### 2. Database Manager (`database.py`)
- Handles SQLite database operations
- Manages stores, orders, and inventory data
- Provides CRUD operations for all entities
- **Problem addressed**: Data persistence and management
- **Solution**: SQLite with proper table relationships and indexing

### 3. AI Integration (`gemini_ai.py`)
- Integrates Google Gemini AI for message analysis
- Extracts order information from natural language
- Supports Arabic language processing and content generation
- **Problem addressed**: Automatic order detection and content creation
- **Solution**: AI-powered message analysis with confidence scoring and content generation

### 4. Bot Handlers (`handlers.py`)
- Manages all Telegram bot interactions
- Handles user commands and callback queries
- Implements conversation flows and AI automation controls
- **Problem addressed**: User interaction and comprehensive automation management
- **Solution**: Structured handler system with conversation states and AI control panels

### 5. Social Media Manager (`social_media_manager.py`) - NEW
- **Fully automated social media management with AI**
- Monitors Facebook, Instagram, and TikTok pages in real-time
- Automatically detects orders from comments and messages
- Provides intelligent auto-replies customized for each platform
- **Problem addressed**: Manual social media management and response delays
- **Solution**: AI-powered 24/7 monitoring and automated customer engagement

### 6. Content Manager (`content_manager.py`) - NEW
- **AI-powered content generation and posting system**
- Creates daily content for products, promotions, and engagement
- Generates platform-specific posts with optimal hashtags
- Schedules and auto-posts content at optimal times
- **Problem addressed**: Time-consuming content creation and posting
- **Solution**: Complete AI automation for content marketing pipeline

### 7. Inventory Manager (`inventory_manager.py`) - NEW
- **Intelligent inventory management with predictive analytics**
- Monitors stock levels and predicts demand patterns
- Provides automatic reorder recommendations
- Optimizes pricing based on demand analysis
- **Problem addressed**: Manual inventory tracking and poor demand forecasting
- **Solution**: AI-driven inventory optimization with predictive analytics

### 8. Notification System (`notifications.py`)
- Sends real-time notifications to store owners
- Handles admin notifications and AI automation alerts
- Manages order alerts and system updates
- **Problem addressed**: Real-time communication with users
- **Solution**: Telegram bot API for instant messaging with automation alerts

### 9. Main Application (`main.py`)
- Orchestrates all components including AI automation modules
- Manages bot lifecycle and error handling
- Sets up conversation handlers and routing
- **Problem addressed**: Application coordination and startup
- **Solution**: Centralized application management with proper error handling

## Data Flow

1. **Store Registration**: Users register their stores through a conversation flow
2. **Message Analysis**: AI analyzes incoming messages for order detection
3. **Order Processing**: Detected orders are stored in the database
4. **Notification**: Store owners receive instant notifications about new orders
5. **Admin Management**: Admin can view and manage all stores and orders

## External Dependencies

### Required APIs
- **Telegram Bot API**: For bot functionality and messaging
- **Google Gemini AI API**: For intelligent message analysis

### Python Libraries
- `python-telegram-bot`: Telegram bot framework
- `google-generativeai`: Google Gemini AI integration
- `sqlite3`: Database operations
- `pydantic`: Data validation and parsing

## Deployment Strategy

### Environment Variables Required
- `BOT_TOKEN`: Telegram bot token
- `GEMINI_API_KEY`: Google Gemini API key
- `ADMIN_ID`: Telegram user ID of the admin

### Database Setup
- SQLite database automatically initialized on first run
- No external database server required
- Database file stored locally as `stores.db`

### Scaling Considerations
- Current architecture suitable for small to medium businesses
- Can be enhanced with PostgreSQL for larger deployments
- Modular design allows easy component replacement

## Changelog
- July 06, 2025. Initial setup and complete implementation of Arabic Telegram Bot "سومر أتمتة AI"
- July 06, 2025. Enhanced with direct message handling for customer communications
- July 07, 2025. Added comprehensive navigation system with back buttons and side navigation
- July 07, 2025. Fixed callback query handling for proper button functionality
- July 07, 2025. MAJOR UPDATE: Added full AI automation system with social media management, content generation, and intelligent inventory management

## User Preferences

Preferred communication style: Simple, everyday language.