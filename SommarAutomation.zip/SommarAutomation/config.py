import os
import logging

# Bot configuration
BOT_TOKEN = os.getenv("BOT_TOKEN", "your_bot_token_here")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "your_gemini_api_key_here")

# Admin configuration
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))  # Replace with actual admin Telegram ID

# Database configuration
DATABASE_PATH = "stores.db"

# Logging configuration
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Conversation states
(
    STORE_NAME, STORE_FACEBOOK, STORE_TIKTOK, STORE_INSTAGRAM,
    STORE_TELEGRAM, STORE_LOCATION, CONFIRMATION,
    ADMIN_ACTION, ADMIN_STORE_ID, INVENTORY_ITEM, INVENTORY_QUANTITY
) = range(11)

# Emojis for better UI
EMOJIS = {
    'store': '🏪',
    'orders': '📋',
    'inventory': '📦',
    'help': '❓',
    'admin': '👑',
    'facebook': '📘',
    'tiktok': '🎵',
    'instagram': '📸',
    'telegram': '📱',
    'location': '📍',
    'notification': '🔔',
    'success': '✅',
    'error': '❌',
    'warning': '⚠️',
    'info': 'ℹ️'
}
