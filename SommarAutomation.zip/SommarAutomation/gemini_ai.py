import json
import logging
import os
from typing import Dict, Any, Optional
from google import genai
from google.genai import types
from pydantic import BaseModel

logger = logging.getLogger(__name__)

class OrderAnalysis(BaseModel):
    is_order: bool
    customer_name: str
    customer_phone: str
    order_details: str
    confidence: float

class GeminiAIManager:
    def __init__(self, api_key: str):
        self.client = genai.Client(api_key=api_key)
        self.model = "gemini-2.5-flash"
    
    def analyze_message_for_order(self, message: str, store_context: Dict[str, Any]) -> OrderAnalysis:
        """Analyze a message to determine if it's an order and extract details"""
        try:
            system_prompt = f"""
            أنت مساعد ذكي لتحليل الرسائل الواردة لمتجر "{store_context.get('store_name', 'المتجر')}".
            
            مهمتك هي تحليل الرسالة التالية وتحديد ما إذا كانت تحتوي على طلب شراء أم لا.
            
            إذا كانت الرسالة تحتوي على طلب شراء، استخرج المعلومات التالية:
            - اسم العميل (إذا كان متوفراً)
            - رقم الهاتف (إذا كان متوفراً)
            - تفاصيل الطلب
            - مستوى الثقة في التحليل (من 0 إلى 1)
            
            أرجع النتيجة بصيغة JSON باللغة العربية مع الحقول التالية:
            - is_order: true أو false
            - customer_name: اسم العميل أو "غير محدد"
            - customer_phone: رقم الهاتف أو "غير محدد"
            - order_details: تفاصيل الطلب أو "غير محدد"
            - confidence: مستوى الثقة (رقم من 0 إلى 1)
            """
            
            response = self.client.models.generate_content(
                model=self.model,
                contents=[
                    types.Content(role="user", parts=[types.Part(text=message)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    response_mime_type="application/json",
                    response_schema=OrderAnalysis,
                ),
            )
            
            if response.text:
                data = json.loads(response.text)
                return OrderAnalysis(**data)
            else:
                raise ValueError("Empty response from Gemini")
                
        except Exception as e:
            logger.error(f"Error analyzing message for order: {e}")
            return OrderAnalysis(
                is_order=False,
                customer_name="غير محدد",
                customer_phone="غير محدد",
                order_details="غير محدد",
                confidence=0.0
            )
    
    def generate_smart_reply(self, message: str, store_context: Dict[str, Any]) -> str:
        """Generate a smart reply to a customer message"""
        try:
            system_prompt = f"""
            أنت مساعد ذكي لمتجر "{store_context.get('store_name', 'المتجر')}".
            
            معلومات المتجر:
            - الاسم: {store_context.get('store_name', 'المتجر')}
            - الموقع: {store_context.get('location', 'غير محدد')}
            
            مهمتك هي الرد على رسائل العملاء بطريقة مهذبة ومفيدة وودودة.
            
            إرشادات الرد:
            1. استخدم اللغة العربية
            2. كن مهذباً ومحترماً
            3. قدم معلومات مفيدة عن المتجر
            4. اشكر العميل على اهتمامه
            5. اعرض المساعدة إذا أمكن
            6. لا تتجاوز 200 كلمة
            
            إذا كانت الرسالة تحتوي على طلب شراء، اشكر العميل وأعلمه أن الطلب سيتم مراجعته قريباً.
            """
            
            response = self.client.models.generate_content(
                model=self.model,
                contents=[
                    types.Content(role="user", parts=[types.Part(text=message)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                ),
            )
            
            return response.text or "شكراً لك على رسالتك. سنقوم بالرد عليك في أقرب وقت ممكن."
            
        except Exception as e:
            logger.error(f"Error generating smart reply: {e}")
            return "شكراً لك على رسالتك. سنقوم بالرد عليك في أقرب وقت ممكن."
    
    def analyze_customer_sentiment(self, message: str) -> Dict[str, Any]:
        """Analyze customer sentiment from a message"""
        try:
            system_prompt = """
            حلل المشاعر في الرسالة التالية وأعط تقييماً من 1 إلى 5:
            1 = سلبي جداً
            2 = سلبي
            3 = محايد
            4 = إيجابي
            5 = إيجابي جداً
            
            أرجع النتيجة بصيغة JSON مع الحقول التالية:
            - sentiment_score: رقم من 1 إلى 5
            - sentiment_label: وصف المشاعر باللغة العربية
            - confidence: مستوى الثقة (من 0 إلى 1)
            """
            
            response = self.client.models.generate_content(
                model=self.model,
                contents=[
                    types.Content(role="user", parts=[types.Part(text=message)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    response_mime_type="application/json",
                ),
            )
            
            if response.text:
                return json.loads(response.text)
            else:
                return {
                    "sentiment_score": 3,
                    "sentiment_label": "محايد",
                    "confidence": 0.5
                }
                
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return {
                "sentiment_score": 3,
                "sentiment_label": "محايد",
                "confidence": 0.5
            }
    
    async def generate_content(self, prompt: str) -> str:
        """Generate content using Gemini AI"""
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            
            return response.text if response.text else "لا يمكن إنتاج المحتوى حالياً"
            
        except Exception as e:
            logger.error(f"Error generating content: {e}")
            return "خطأ في إنتاج المحتوى"
