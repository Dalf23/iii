import logging
from typing import Dict, Any
from telegram import Bot
from telegram.error import TelegramError

logger = logging.getLogger(__name__)

class NotificationManager:
    def __init__(self, bot_token: str):
        self.bot = Bot(token=bot_token)
    
    async def send_order_notification(self, telegram_id: int, order_data: Dict[str, Any], store_name: str):
        """Send order notification to store owner"""
        try:
            message = f"""
🔔 *طلب جديد في {store_name}*

👤 *العميل:* {order_data.get('customer_name', 'غير محدد')}
📱 *رقم الهاتف:* {order_data.get('customer_phone', 'غير محدد')}
📋 *تفاصيل الطلب:* {order_data.get('order_details', 'غير محدد')}
📱 *المنصة:* {order_data.get('platform', 'غير محدد')}
🕐 *الوقت:* {order_data.get('created_at', 'الآن')}

يرجى مراجعة الطلب والتواصل مع العميل.
            """
            
            await self.bot.send_message(
                chat_id=telegram_id,
                text=message,
                parse_mode='Markdown'
            )
            logger.info(f"Order notification sent to {telegram_id}")
            
        except TelegramError as e:
            logger.error(f"Failed to send order notification: {e}")
    
    async def send_admin_notification(self, admin_id: int, message: str):
        """Send notification to admin"""
        try:
            await self.bot.send_message(
                chat_id=admin_id,
                text=f"👑 *إشعار الإدارة*\n\n{message}",
                parse_mode='Markdown'
            )
            logger.info(f"Admin notification sent to {admin_id}")
            
        except TelegramError as e:
            logger.error(f"Failed to send admin notification: {e}")
    
    async def send_store_update_notification(self, telegram_id: int, store_name: str, update_type: str):
        """Send store update notification"""
        try:
            message = f"""
✅ *تم تحديث متجر {store_name}*

🔄 *نوع التحديث:* {update_type}
🕐 *الوقت:* الآن

تم حفظ التغييرات بنجاح.
            """
            
            await self.bot.send_message(
                chat_id=telegram_id,
                text=message,
                parse_mode='Markdown'
            )
            logger.info(f"Store update notification sent to {telegram_id}")
            
        except TelegramError as e:
            logger.error(f"Failed to send store update notification: {e}")
