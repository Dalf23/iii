import logging
from typing import Dict, Any
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes, ConversationHandler
from database import DatabaseManager
from gemini_ai import GeminiAIManager
from notifications import NotificationManager
from config import *
from ui_manager import UIManager
from social_media_manager import SocialMediaManager
from content_manager import ContentManager
from inventory_manager import InventoryManager

logger = logging.getLogger(__name__)

class BotHandlers:
    def __init__(self, db_manager: DatabaseManager, ai_manager: GeminiAIManager, notification_manager: NotificationManager):
        self.db = db_manager
        self.ai = ai_manager
        self.notifications = notification_manager
        
        # Initialize AI Management modules
        self.social_media_manager = SocialMediaManager(ai_manager, db_manager)
        self.content_manager = ContentManager(ai_manager, db_manager)
        self.inventory_manager = InventoryManager(ai_manager, db_manager)
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user_id = update.effective_user.id
        user_name = update.effective_user.first_name or "المستخدم"
        
        # Check if user is admin
        is_admin = user_id == ADMIN_ID
        
        # Check if user has a store
        store = self.db.get_store_by_user_id(user_id)
        has_store = store is not None
        
        # Create enhanced main menu with navigation
        reply_markup = UIManager.create_main_menu(is_admin=is_admin, has_store=has_store)
        
        welcome_message = f"""
🤖 *مرحباً {user_name}!*

أهلاً بك في *سومر أتمتة AI* - بوتك الذكي لأتمتة إدارة المتاجر وصفحات التواصل الاجتماعي.

{'👑 *مرحباً بك كمدير!*' if is_admin else ''}

🌟 *ما يمكنني مساعدتك به:*
• إدارة بيانات متجرك
• تتبع الطلبات تلقائياً
• إدارة المخزون
• الرد الذكي على العملاء
• إرسال الإشعارات الفورية

اختر من القائمة أدناه للبدء:
        """
        
        await update.message.reply_text(
            welcome_message,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard button presses"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        user_id = update.effective_user.id
        
        if data == "add_store":
            await self.start_store_registration(update, context)
        elif data == "update_store":
            await self.start_store_registration(update, context)
        elif data == "view_orders":
            await self.view_orders(update, context)
        elif data == "manage_inventory":
            await self.manage_inventory_menu(update, context)
        elif data == "admin_panel":
            await self.admin_panel(update, context)
        elif data == "help":
            await self.show_help(update, context)
        elif data.startswith("admin_"):
            await self.handle_admin_actions(update, context)
        elif data.startswith("inventory_"):
            await self.handle_inventory_actions(update, context)
        elif data.startswith("select_store_"):
            store_id = int(data.replace("select_store_", ""))
            await self.handle_store_selection(update, context, store_id)
        elif data == "contact_admin":
            await self.handle_contact_admin(update, context)
        elif data == "back_to_main":
            await self.go_back_to_main(update, context)
        elif data.startswith("orders_"):
            await self.handle_orders_actions(update, context)
        elif data == "ai_automation":
            await self.show_ai_automation_menu(update, context)
        elif data == "social_media_management":
            await self.show_social_media_menu(update, context)
        elif data == "content_management":
            await self.show_content_management_menu(update, context)
        elif data.startswith("start_monitoring"):
            await self.handle_start_monitoring(update, context)
        elif data.startswith("stop_monitoring"):
            await self.handle_stop_monitoring(update, context)
        elif data.startswith("generate_daily_content"):
            await self.handle_generate_content(update, context)
        elif data.startswith("analyze_inventory"):
            await self.handle_analyze_inventory(update, context)
    
    async def start_store_registration(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Start store registration process"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        # Check if updating existing store
        existing_store = self.db.get_store_by_user_id(user_id)
        context.user_data['updating_store'] = existing_store is not None
        
        message = f"""
{EMOJIS['store']} *{'تحديث' if existing_store else 'إضافة'} بيانات المتجر*

سأقوم بجمع بيانات متجرك خطوة بخطوة.

{EMOJIS['info']} أدخل اسم المتجر:
        """
        
        await query.edit_message_text(
            message,
            parse_mode='Markdown'
        )
        
        return STORE_NAME
    
    async def collect_store_name(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Collect store name"""
        store_name = update.message.text.strip()
        
        if not store_name:
            await update.message.reply_text(
                f"{EMOJIS['error']} يرجى إدخال اسم صحيح للمتجر."
            )
            return STORE_NAME
        
        context.user_data['store_data'] = {'name': store_name}
        
        await update.message.reply_text(
            f"{EMOJIS['facebook']} أدخل رابط صفحة الفيسبوك (أو اكتب 'تخطي' للتخطي):"
        )
        
        return STORE_FACEBOOK
    
    async def collect_facebook_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Collect Facebook URL"""
        facebook_url = update.message.text.strip()
        
        if facebook_url.lower() in ['تخطي', 'skip']:
            context.user_data['store_data']['facebook'] = None
        else:
            context.user_data['store_data']['facebook'] = facebook_url
        
        await update.message.reply_text(
            f"{EMOJIS['tiktok']} أدخل رابط صفحة التيك توك (أو اكتب 'تخطي' للتخطي):"
        )
        
        return STORE_TIKTOK
    
    async def collect_tiktok_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Collect TikTok URL"""
        tiktok_url = update.message.text.strip()
        
        if tiktok_url.lower() in ['تخطي', 'skip']:
            context.user_data['store_data']['tiktok'] = None
        else:
            context.user_data['store_data']['tiktok'] = tiktok_url
        
        await update.message.reply_text(
            f"{EMOJIS['instagram']} أدخل رابط صفحة الإنستقرام (أو اكتب 'تخطي' للتخطي):"
        )
        
        return STORE_INSTAGRAM
    
    async def collect_instagram_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Collect Instagram URL"""
        instagram_url = update.message.text.strip()
        
        if instagram_url.lower() in ['تخطي', 'skip']:
            context.user_data['store_data']['instagram'] = None
        else:
            context.user_data['store_data']['instagram'] = instagram_url
        
        await update.message.reply_text(
            f"{EMOJIS['telegram']} أدخل معرف التليجرام الخاص بك لاستقبال الإشعارات (مثل: @username أو User ID):"
        )
        
        return STORE_TELEGRAM
    
    async def collect_telegram_id(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Collect Telegram ID for notifications"""
        telegram_input = update.message.text.strip()
        
        # Try to extract user ID (simplified - in production, you'd want better validation)
        if telegram_input.startswith('@'):
            # For simplicity, we'll use the current user's ID
            telegram_id = update.effective_user.id
        else:
            try:
                telegram_id = int(telegram_input)
            except ValueError:
                telegram_id = update.effective_user.id
        
        context.user_data['store_data']['telegram_id'] = telegram_id
        
        await update.message.reply_text(
            f"{EMOJIS['location']} أدخل موقع المتجر (أو اكتب 'تخطي' للتخطي):"
        )
        
        return STORE_LOCATION
    
    async def collect_location(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Collect store location"""
        location = update.message.text.strip()
        
        if location.lower() in ['تخطي', 'skip']:
            context.user_data['store_data']['location'] = None
        else:
            context.user_data['store_data']['location'] = location
        
        # Show confirmation
        store_data = context.user_data['store_data']
        
        confirmation_message = f"""
{EMOJIS['info']} *مراجعة بيانات المتجر:*

{EMOJIS['store']} *الاسم:* {store_data['name']}
{EMOJIS['facebook']} *الفيسبوك:* {store_data.get('facebook') or 'غير محدد'}
{EMOJIS['tiktok']} *التيك توك:* {store_data.get('tiktok') or 'غير محدد'}
{EMOJIS['instagram']} *الإنستقرام:* {store_data.get('instagram') or 'غير محدد'}
{EMOJIS['telegram']} *التليجرام:* {store_data.get('telegram_id')}
{EMOJIS['location']} *الموقع:* {store_data.get('location') or 'غير محدد'}

هل تريد حفظ هذه البيانات؟
        """
        
        keyboard = [
            [
                InlineKeyboardButton(f"{EMOJIS['success']} حفظ", callback_data="confirm_store"),
                InlineKeyboardButton(f"{EMOJIS['error']} إلغاء", callback_data="cancel_store")
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            confirmation_message,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
        return CONFIRMATION
    
    async def confirm_store_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Confirm and save store data"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "confirm_store":
            user_id = update.effective_user.id
            store_data = context.user_data['store_data']
            
            success = self.db.add_store(user_id, store_data)
            
            if success:
                await query.edit_message_text(
                    f"{EMOJIS['success']} *تم حفظ بيانات المتجر بنجاح!*\n\n"
                    f"يمكنك الآن الاستفادة من جميع مزايا البوت.",
                    parse_mode='Markdown'
                )
                
                # Send notification to store owner
                await self.notifications.send_store_update_notification(
                    store_data['telegram_id'],
                    store_data['name'],
                    "تسجيل متجر جديد" if not context.user_data.get('updating_store') else "تحديث بيانات المتجر"
                )
                
            else:
                await query.edit_message_text(
                    f"{EMOJIS['error']} حدث خطأ أثناء حفظ البيانات. يرجى المحاولة مرة أخرى."
                )
        
        else:  # cancel_store
            await query.edit_message_text(
                f"{EMOJIS['warning']} تم إلغاء العملية."
            )
        
        # Clear user data
        context.user_data.clear()
        return ConversationHandler.END
    
    async def view_orders(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """View current orders with enhanced navigation"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        store = self.db.get_store_by_user_id(user_id)
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        # Show orders menu first
        reply_markup = UIManager.create_orders_menu()
        
        message = UIManager.add_navigation_to_message(
            f"{EMOJIS['orders']} *إدارة الطلبات - {store['store_name']}*\n\n"
            f"اختر نوع الطلبات التي تريد عرضها:",
            "orders",
            "استخدم الأزرار للتنقل بين الأقسام"
        )
        
        await query.edit_message_text(
            message,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def manage_inventory_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show inventory management menu with enhanced navigation"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        store = self.db.get_store_by_user_id(user_id)
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        reply_markup = UIManager.create_inventory_menu()
        
        message = UIManager.add_navigation_to_message(
            f"{EMOJIS['inventory']} *إدارة المخزون - {store['store_name']}*\n\n"
            f"اختر العملية المطلوبة لإدارة المخزون:",
            "inventory",
            "يمكنك إضافة وتحديث وحذف المنتجات"
        )
        
        await query.edit_message_text(
            message,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def handle_inventory_actions(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inventory-related actions"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        store = self.db.get_store_by_user_id(user_id)
        
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً."
            )
            return
        
        if query.data == "inventory_view":
            inventory = self.db.get_inventory_by_store(store['id'])
            
            if not inventory:
                await query.edit_message_text(
                    f"{EMOJIS['info']} المخزون فارغ حالياً."
                )
                return
            
            message = f"{EMOJIS['inventory']} *مخزون {store['store_name']}:*\n\n"
            
            for item in inventory:
                message += f"""
📦 *المنتج:* {item['item_name']}
🔢 *الكمية:* {item['quantity']}
💰 *السعر:* {item['price']} 
📝 *الوصف:* {item['description'] or 'غير محدد'}
🕐 *آخر تحديث:* {item['updated_at']}
---
                """
            
            await query.edit_message_text(
                message,
                parse_mode='Markdown'
            )
    
    async def admin_panel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show admin panel with enhanced navigation"""
        query = update.callback_query
        user_id = update.effective_user.id
        
        if user_id != ADMIN_ID:
            await query.edit_message_text(
                f"{EMOJIS['error']} غير مسموح لك بالوصول لهذه الصفحة.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        stores = self.db.get_all_stores()
        reply_markup = UIManager.create_admin_menu(len(stores))
        
        message = UIManager.add_navigation_to_message(
            f"{EMOJIS['admin']} *لوحة تحكم الإدارة*\n\n"
            f"📊 إجمالي المتاجر المسجلة: {len(stores)}\n"
            f"📈 النشاط: البوت يعمل بشكل طبيعي\n\n"
            f"اختر العملية المطلوبة:",
            "admin",
            "يمكنك إدارة جميع المتاجر والمستخدمين"
        )
        
        await query.edit_message_text(
            message,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def handle_admin_actions(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle admin actions"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        
        if user_id != ADMIN_ID:
            await query.edit_message_text(
                f"{EMOJIS['error']} غير مسموح لك بالوصول لهذه الصفحة."
            )
            return
        
        if query.data == "admin_view_stores":
            stores = self.db.get_all_stores()
            
            if not stores:
                await query.edit_message_text(
                    f"{EMOJIS['info']} لا توجد متاجر مسجلة حالياً."
                )
                return
            
            message = f"{EMOJIS['store']} *جميع المتاجر المسجلة:*\n\n"
            
            for store in stores:
                message += f"""
🏪 *{store['store_name']}*
👤 *المالك:* {store['user_id']}
📱 *التليجرام:* {store['telegram_id']}
📍 *الموقع:* {store['location'] or 'غير محدد'}
📅 *تاريخ التسجيل:* {store['created_at']}
---
                """
            
            await query.edit_message_text(
                message,
                parse_mode='Markdown'
            )
    
    async def show_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show help information"""
        query = update.callback_query
        
        help_message = f"""
{EMOJIS['help']} *المساعدة والدعم الفني*

🤖 *حول سومر أتمتة AI:*
بوت ذكي لأتمتة إدارة المتاجر وصفحات التواصل الاجتماعي باستخدام الذكاء الاصطناعي.

⭐ *المميزات الرئيسية:*
• إدارة بيانات المتاجر
• تتبع الطلبات تلقائياً
• إدارة المخزون
• الرد الذكي على العملاء
• إرسال الإشعارات الفورية

📞 *للدعم الفني:*
في حالة وجود مشاكل أو استفسارات، يرجى التواصل مع الإدارة.

🔧 *كيفية البدء:*
1. اضغط على "إضافة بيانات المتجر"
2. أدخل المعلومات المطلوبة
3. احفظ البيانات
4. ابدأ في استخدام البوت

💡 *نصائح مهمة:*
• تأكد من صحة معرف التليجرام لاستقبال الإشعارات
• قم بتحديث بيانات المتجر عند الحاجة
• راجع الطلبات بانتظام
        """
        
        await query.edit_message_text(
            help_message,
            parse_mode='Markdown'
        )
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle incoming messages (for AI analysis and direct messages)"""
        message_text = update.message.text
        user_id = update.effective_user.id
        user_name = update.effective_user.first_name or "العميل"
        
        # Check if this is a store owner
        store = self.db.get_store_by_user_id(user_id)
        
        if store:
            # This is a store owner testing the bot
            await self.handle_store_owner_message(update, context, store)
        else:
            # This is a potential customer message - handle as direct message
            await self.handle_customer_direct_message(update, context, user_name)
    
    async def handle_store_owner_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE, store: dict):
        """Handle messages from store owners"""
        message_text = update.message.text
        
        try:
            # Generate smart reply
            smart_reply = self.ai.generate_smart_reply(message_text, store)
            
            # Analyze for potential order
            order_analysis = self.ai.analyze_message_for_order(message_text, store)
            
            # Log the message
            self.db.log_message(store['id'], 'telegram', message_text, smart_reply)
            
            # Send smart reply
            await update.message.reply_text(
                f"{EMOJIS['info']} *الرد الذكي:*\n\n{smart_reply}",
                parse_mode='Markdown'
            )
            
            # If it's likely an order, save it and notify
            if order_analysis.is_order and order_analysis.confidence > 0.7:
                order_data = {
                    'customer_name': order_analysis.customer_name,
                    'customer_phone': order_analysis.customer_phone,
                    'order_details': order_analysis.order_details,
                    'platform': 'telegram',
                    'created_at': 'الآن'
                }
                
                # Save order
                success = self.db.add_order(store['id'], order_data)
                
                if success:
                    # Send notification to store owner
                    await self.notifications.send_order_notification(
                        store['telegram_id'],
                        order_data,
                        store['store_name']
                    )
                    
                    await update.message.reply_text(
                        f"{EMOJIS['success']} تم تسجيل الطلب وإرسال إشعار لصاحب المتجر!"
                    )
                
        except Exception as e:
            logger.error(f"Error handling store owner message: {e}")
            await update.message.reply_text(
                f"{EMOJIS['error']} حدث خطأ في تحليل الرسالة. يرجى المحاولة مرة أخرى."
            )
    
    async def handle_customer_direct_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE, user_name: str):
        """Handle direct messages from customers with enhanced functionality"""
        try:
            # Import the enhanced handler
            from direct_message_handler import DirectMessageHandler
            
            # Create enhanced handler instance
            dm_handler = DirectMessageHandler(self.db, self.ai, self.notifications)
            
            # Use enhanced direct message handling
            await dm_handler.handle_direct_message(update, context, user_name)
            
        except Exception as e:
            logger.error(f"Error in direct message handling: {e}")
            await update.message.reply_text(
                f"{EMOJIS['error']} حدث خطأ في معالجة الرسالة. يرجى المحاولة مرة أخرى."
            )
    
    async def handle_store_selection(self, update: Update, context: ContextTypes.DEFAULT_TYPE, store_id: int):
        """Handle store selection from direct message customers"""
        try:
            from direct_message_handler import DirectMessageHandler
            dm_handler = DirectMessageHandler(self.db, self.ai, self.notifications)
            await dm_handler.handle_store_selection(update, context, store_id)
        except Exception as e:
            logger.error(f"Error handling store selection: {e}")
            query = update.callback_query
            await query.answer()
            await query.edit_message_text(
                f"{EMOJIS['error']} حدث خطأ. يرجى المحاولة مرة أخرى."
            )
    
    async def handle_contact_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle contact admin request"""
        query = update.callback_query
        await query.answer()
        
        user_name = update.effective_user.first_name or "المستخدم"
        user_id = update.effective_user.id
        
        await query.edit_message_text(
            f"{EMOJIS['info']} تم إرسال طلبك للإدارة.\n\n"
            f"سيتم التواصل معك قريباً عبر التليجرام."
        )
        
        # Notify admin
        await self.notifications.send_admin_notification(
            ADMIN_ID,
            f"طلب تواصل من العميل {user_name} (ID: {user_id})\n"
            f"يرجى التواصل معه مباشرة."
        )
    
    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel current operation"""
        await update.message.reply_text(
            f"{EMOJIS['warning']} تم إلغاء العملية الحالية."
        )
        context.user_data.clear()
        return ConversationHandler.END
    
    async def handle_orders_actions(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle orders-related actions"""
        query = update.callback_query
        await query.answer()
        
        data = query.data
        user_id = update.effective_user.id
        
        store = self.db.get_store_by_user_id(user_id)
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        if data == "orders_current":
            await self.show_orders_list(query, store, "pending")
        elif data == "orders_completed":
            await self.show_orders_list(query, store, "completed")
        elif data == "orders_pending":
            await self.show_orders_list(query, store, "pending")
        elif data == "orders_search":
            await query.edit_message_text(
                f"{EMOJIS['info']} ميزة البحث ستتوفر قريباً...",
                reply_markup=InlineKeyboardMarkup(UIManager.create_navigation_menu("orders"))
            )
    
    async def show_orders_list(self, query, store: Dict[str, Any], status_filter: str = None):
        """Show filtered orders list with pagination"""
        orders = self.db.get_orders_by_store(store['id'])
        
        if status_filter:
            orders = [order for order in orders if order['status'] == status_filter]
        
        if not orders:
            status_text = {
                'pending': 'معلقة',
                'completed': 'مكتملة',
                'cancelled': 'ملغية'
            }.get(status_filter, 'حالية')
            
            await query.edit_message_text(
                f"{EMOJIS['info']} لا توجد طلبات {status_text} حالياً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_navigation_menu("orders"))
            )
            return
        
        # Format orders with pagination
        message, total_pages = UIManager.format_orders_list(orders, page=1, per_page=3)
        
        # Create keyboard with pagination if needed
        keyboard = []
        if total_pages > 1:
            keyboard.extend(UIManager.create_pagination_menu(1, total_pages, f"orders_{status_filter}"))
        
        keyboard.extend(UIManager.create_navigation_menu("orders"))
        
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            parse_mode='Markdown'
        )
    
    async def go_back_to_main(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle back to main menu from callback query"""
        query = update.callback_query
        user_id = update.effective_user.id
        user_name = update.effective_user.first_name or "المستخدم"
        
        # Check if user is admin
        is_admin = user_id == ADMIN_ID
        
        # Check if user has a store
        store = self.db.get_store_by_user_id(user_id)
        has_store = store is not None
        
        # Create enhanced main menu with navigation
        reply_markup = UIManager.create_main_menu(is_admin=is_admin, has_store=has_store)
        
        welcome_message = f"""
🤖 *مرحباً {user_name}!*

أهلاً بك في *سومر أتمتة AI* - بوتك الذكي لأتمتة إدارة المتاجر وصفحات التواصل الاجتماعي.

{'👑 *مرحباً بك كمدير!*' if is_admin else ''}

🌟 *ما يمكنني مساعدتك به:*
• إدارة بيانات متجرك
• تتبع الطلبات تلقائياً
• إدارة المخزون
• الرد الذكي على العملاء
• إرسال الإشعارات الفورية

اختر من القائمة أدناه للبدء:
        """
        
        await query.edit_message_text(
            welcome_message,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
    
    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Cancel current operation"""
        await update.message.reply_text(
            f"{EMOJIS['warning']} تم إلغاء العملية."
        )
        context.user_data.clear()
        return ConversationHandler.END
    
    async def show_ai_automation_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show AI automation control menu"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        store = self.db.get_store_by_user_id(user_id)
        
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        monitoring_status = self.social_media_manager.get_monitoring_status()
        inventory_status = self.inventory_manager.get_inventory_status(store['id'])
        
        status_message = f"""
🤖 *لوحة تحكم الذكاء الاصطناعي*

📊 *حالة النظام:*
• مراقبة الصفحات: {'🟢 مفعل' if monitoring_status['monitoring_active'] else '🔴 معطل'}
• الرد التلقائي: {'🟢 مفعل' if monitoring_status['auto_reply_enabled'] else '🔴 معطل'}
• إدارة المخزون: {'🟢 مفعل' if inventory_status['monitoring_active'] else '🔴 معطل'}

📈 *إحصائيات سريعة:*
• إجمالي المنتجات: {inventory_status.get('total_items', 0)}
• منتجات قليلة المخزون: {inventory_status.get('low_stock_items', 0)}
• منتجات نافدة: {inventory_status.get('out_of_stock_items', 0)}

🚀 *اختر الإجراء المطلوب من الأزرار أدناه:*
        """
        
        await query.edit_message_text(
            status_message,
            reply_markup=UIManager.create_ai_automation_menu(),
            parse_mode='Markdown'
        )
    
    async def show_social_media_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show social media management menu"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        store = self.db.get_store_by_user_id(user_id)
        
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        social_info = f"""
📱 *إدارة منصات التواصل الاجتماعي*

🔗 *الحسابات المربوطة:*
• Facebook: {'✅ مربوط' if store.get('facebook_url') else '❌ غير مربوط'}
• Instagram: {'✅ مربوط' if store.get('instagram_url') else '❌ غير مربوط'}
• TikTok: {'✅ مربوط' if store.get('tiktok_url') else '❌ غير مربوط'}

🤖 *الميزات المتاحة:*
• مراقبة التعليقات والرسائل
• الرد التلقائي بالذكاء الاصطناعي
• اكتشاف الطلبات تلقائياً
• تحليل مشاعر العملاء

📊 *اختر الإجراء المطلوب:*
        """
        
        await query.edit_message_text(
            social_info,
            reply_markup=UIManager.create_social_media_menu(),
            parse_mode='Markdown'
        )
    
    async def show_content_management_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show content management menu"""
        query = update.callback_query
        await query.answer()
        
        user_id = update.effective_user.id
        store = self.db.get_store_by_user_id(user_id)
        
        if not store:
            await query.edit_message_text(
                f"{EMOJIS['error']} يرجى إضافة بيانات المتجر أولاً.",
                reply_markup=InlineKeyboardMarkup(UIManager.create_back_button())
            )
            return
        
        content_analytics = self.content_manager.get_content_analytics(store['id'])
        
        content_info = f"""
📝 *إدارة المحتوى بالذكاء الاصطناعي*

📊 *إحصائيات المحتوى:*
• إجمالي المحتوى المولد: {content_analytics.get('total_content_generated', 0)}
• المحتوى المنشور اليوم: {content_analytics.get('content_posted_today', 0)}
• معدل التفاعل: {content_analytics.get('engagement_rate', 0):.1%}
• أفضل منصة أداءً: {content_analytics.get('best_performing_platform', 'Instagram')}

🎨 *أنواع المحتوى المتاحة:*
• منشورات المنتجات
• العروض والخصومات
• قصص نجاح العملاء
• محتوى تفاعلي

🚀 *اختر الإجراء المطلوب:*
        """
        
        await query.edit_message_text(
            content_info,
            reply_markup=UIManager.create_content_management_menu(),
            parse_mode='Markdown'
        )
