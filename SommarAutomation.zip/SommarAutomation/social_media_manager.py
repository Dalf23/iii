"""
Social Media Manager - ربط مع منصات التواصل الاجتماعي
يدير التفاعل التلقائي مع Facebook, Instagram, TikTok
"""

import logging
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import aiohttp
import requests
from config import *
from gemini_ai import GeminiAIManager

logger = logging.getLogger(__name__)

@dataclass
class SocialMediaPost:
    """بيانات المنشور على وسائل التواصل"""
    platform: str
    post_id: str
    content: str
    author: str
    timestamp: datetime
    comments: List[Dict] = None
    likes: int = 0
    shares: int = 0

@dataclass
class AutoReply:
    """الرد التلقائي"""
    message: str
    confidence: float
    reply_type: str  # 'order', 'inquiry', 'support', 'general'
    should_auto_reply: bool = True

class SocialMediaManager:
    """مدير وسائل التواصل الاجتماعي مع الذكاء الاصطناعي"""
    
    def __init__(self, ai_manager: GeminiAIManager, db_manager):
        self.ai_manager = ai_manager
        self.db_manager = db_manager
        self.active_sessions = {}
        self.auto_reply_enabled = True
        self.monitoring_active = False
        
    async def start_monitoring(self, store_id: int):
        """بدء مراقبة الصفحات التلقائية"""
        try:
            store = self.db_manager.get_store_by_id(store_id)
            if not store:
                return False
                
            self.monitoring_active = True
            logger.info(f"🔄 بدء مراقبة صفحات المتجر: {store['name']}")
            
            # مراقبة متوازية لجميع المنصات
            tasks = []
            if store.get('facebook_url'):
                tasks.append(self.monitor_facebook_page(store))
            if store.get('instagram_url'):
                tasks.append(self.monitor_instagram_page(store))
            if store.get('tiktok_url'):
                tasks.append(self.monitor_tiktok_page(store))
                
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
                
            return True
            
        except Exception as e:
            logger.error(f"خطأ في بدء المراقبة: {e}")
            return False
    
    async def monitor_facebook_page(self, store: Dict):
        """مراقبة صفحة Facebook"""
        try:
            page_id = self.extract_facebook_page_id(store['facebook_url'])
            if not page_id:
                return
                
            while self.monitoring_active:
                # جلب المنشورات والتعليقات الجديدة
                posts = await self.fetch_facebook_posts(page_id)
                
                for post in posts:
                    await self.process_facebook_post(store, post)
                
                # انتظار قبل التحقق مرة أخرى
                await asyncio.sleep(30)  # كل 30 ثانية
                
        except Exception as e:
            logger.error(f"خطأ في مراقبة Facebook: {e}")
    
    async def monitor_instagram_page(self, store: Dict):
        """مراقبة صفحة Instagram"""
        try:
            username = self.extract_instagram_username(store['instagram_url'])
            if not username:
                return
                
            while self.monitoring_active:
                # جلب المنشورات والتعليقات الجديدة
                posts = await self.fetch_instagram_posts(username)
                
                for post in posts:
                    await self.process_instagram_post(store, post)
                
                await asyncio.sleep(30)
                
        except Exception as e:
            logger.error(f"خطأ في مراقبة Instagram: {e}")
    
    async def monitor_tiktok_page(self, store: Dict):
        """مراقبة صفحة TikTok"""
        try:
            username = self.extract_tiktok_username(store['tiktok_url'])
            if not username:
                return
                
            while self.monitoring_active:
                # جلب المنشورات والتعليقات الجديدة
                posts = await self.fetch_tiktok_posts(username)
                
                for post in posts:
                    await self.process_tiktok_post(store, post)
                
                await asyncio.sleep(30)
                
        except Exception as e:
            logger.error(f"خطأ في مراقبة TikTok: {e}")
    
    async def process_facebook_post(self, store: Dict, post: SocialMediaPost):
        """معالجة منشور Facebook"""
        try:
            # تحليل التعليقات للبحث عن طلبات
            if post.comments:
                for comment in post.comments:
                    await self.analyze_and_reply_facebook(store, post, comment)
                    
        except Exception as e:
            logger.error(f"خطأ في معالجة منشور Facebook: {e}")
    
    async def process_instagram_post(self, store: Dict, post: SocialMediaPost):
        """معالجة منشور Instagram"""
        try:
            # تحليل التعليقات للبحث عن طلبات
            if post.comments:
                for comment in post.comments:
                    await self.analyze_and_reply_instagram(store, post, comment)
                    
        except Exception as e:
            logger.error(f"خطأ في معالجة منشور Instagram: {e}")
    
    async def process_tiktok_post(self, store: Dict, post: SocialMediaPost):
        """معالجة منشور TikTok"""
        try:
            # تحليل التعليقات للبحث عن طلبات
            if post.comments:
                for comment in post.comments:
                    await self.analyze_and_reply_tiktok(store, post, comment)
                    
        except Exception as e:
            logger.error(f"خطأ في معالجة منشور TikTok: {e}")
    
    async def analyze_and_reply_facebook(self, store: Dict, post: SocialMediaPost, comment: Dict):
        """تحليل والرد على تعليق Facebook"""
        try:
            # تحليل التعليق بالذكاء الاصطناعي
            analysis = self.ai_manager.analyze_message_for_order(
                comment['message'], 
                store
            )
            
            # إنشاء رد ذكي
            reply = await self.generate_smart_reply(
                comment['message'], 
                store, 
                analysis,
                'facebook'
            )
            
            if reply.should_auto_reply:
                # نشر الرد تلقائياً
                await self.post_facebook_reply(post.post_id, comment['id'], reply.message)
                
                # تسجيل الطلب إذا تم اكتشافه
                if analysis.is_order:
                    await self.log_detected_order(store, analysis, 'facebook', comment)
                    
        except Exception as e:
            logger.error(f"خطأ في تحليل والرد على Facebook: {e}")
    
    async def analyze_and_reply_instagram(self, store: Dict, post: SocialMediaPost, comment: Dict):
        """تحليل والرد على تعليق Instagram"""
        try:
            analysis = self.ai_manager.analyze_message_for_order(
                comment['message'], 
                store
            )
            
            reply = await self.generate_smart_reply(
                comment['message'], 
                store, 
                analysis,
                'instagram'
            )
            
            if reply.should_auto_reply:
                await self.post_instagram_reply(post.post_id, comment['id'], reply.message)
                
                if analysis.is_order:
                    await self.log_detected_order(store, analysis, 'instagram', comment)
                    
        except Exception as e:
            logger.error(f"خطأ في تحليل والرد على Instagram: {e}")
    
    async def analyze_and_reply_tiktok(self, store: Dict, post: SocialMediaPost, comment: Dict):
        """تحليل والرد على تعليق TikTok"""
        try:
            analysis = self.ai_manager.analyze_message_for_order(
                comment['message'], 
                store
            )
            
            reply = await self.generate_smart_reply(
                comment['message'], 
                store, 
                analysis,
                'tiktok'
            )
            
            if reply.should_auto_reply:
                await self.post_tiktok_reply(post.post_id, comment['id'], reply.message)
                
                if analysis.is_order:
                    await self.log_detected_order(store, analysis, 'tiktok', comment)
                    
        except Exception as e:
            logger.error(f"خطأ في تحليل والرد على TikTok: {e}")
    
    async def generate_smart_reply(self, message: str, store: Dict, analysis, platform: str) -> AutoReply:
        """إنشاء رد ذكي مخصص لكل منصة"""
        try:
            # تحديد نوع الرد بناءً على التحليل
            if analysis.is_order:
                reply_type = 'order'
                base_message = f"شكراً لك على طلبك! تم استلام طلبك وسيتم التواصل معك قريباً عبر الخاص للتأكيد."
            else:
                reply_type = 'inquiry'
                base_message = self.ai_manager.generate_smart_reply(message, store)
            
            # تخصيص الرد لكل منصة
            platform_specific_reply = self.customize_reply_for_platform(
                base_message, 
                platform, 
                store
            )
            
            return AutoReply(
                message=platform_specific_reply,
                confidence=analysis.confidence if hasattr(analysis, 'confidence') else 0.8,
                reply_type=reply_type,
                should_auto_reply=True
            )
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء الرد الذكي: {e}")
            return AutoReply(
                message="شكراً لك على رسالتك!",
                confidence=0.5,
                reply_type='general',
                should_auto_reply=True
            )
    
    def customize_reply_for_platform(self, base_message: str, platform: str, store: Dict) -> str:
        """تخصيص الرد لكل منصة"""
        try:
            if platform == 'facebook':
                return f"{base_message}\n\n📧 للتواصل المباشر: {store.get('contact_info', 'رسالة خاصة')}"
            elif platform == 'instagram':
                return f"{base_message}\n\n📩 راسلنا في الخاص للتفاصيل"
            elif platform == 'tiktok':
                return f"{base_message}\n\n💬 اكتب لنا رسالة للتفاصيل"
            else:
                return base_message
                
        except Exception as e:
            logger.error(f"خطأ في تخصيص الرد: {e}")
            return base_message
    
    async def log_detected_order(self, store: Dict, analysis, platform: str, comment: Dict):
        """تسجيل الطلب المكتشف"""
        try:
            order_data = {
                'customer_name': analysis.customer_name,
                'customer_phone': analysis.customer_phone,
                'order_details': analysis.order_details,
                'platform': platform,
                'status': 'pending',
                'confidence': analysis.confidence,
                'original_message': comment['message'],
                'comment_id': comment['id'],
                'timestamp': datetime.now().isoformat()
            }
            
            # حفظ الطلب في قاعدة البيانات
            success = self.db_manager.add_order(store['id'], order_data)
            
            if success:
                logger.info(f"✅ تم تسجيل طلب جديد من {platform}")
                
                # إرسال إشعار لصاحب المتجر
                await self.send_new_order_notification(store, order_data)
            
        except Exception as e:
            logger.error(f"خطأ في تسجيل الطلب: {e}")
    
    async def send_new_order_notification(self, store: Dict, order_data: Dict):
        """إرسال إشعار طلب جديد"""
        try:
            # إرسال إشعار عبر التليجرام
            from notifications import NotificationManager
            notification_manager = NotificationManager(BOT_TOKEN)
            
            await notification_manager.send_order_notification(
                store['telegram_id'],
                order_data,
                store['name']
            )
            
        except Exception as e:
            logger.error(f"خطأ في إرسال الإشعار: {e}")
    
    # دوال API للمنصات الاجتماعية
    async def fetch_facebook_posts(self, page_id: str) -> List[SocialMediaPost]:
        """جلب منشورات Facebook"""
        try:
            # هذه الدالة تحتاج Facebook API Token
            # يمكن تطويرها مع الحصول على الصلاحيات المناسبة
            return []
        except Exception as e:
            logger.error(f"خطأ في جلب منشورات Facebook: {e}")
            return []
    
    async def fetch_instagram_posts(self, username: str) -> List[SocialMediaPost]:
        """جلب منشورات Instagram"""
        try:
            # هذه الدالة تحتاج Instagram API Token
            # يمكن تطويرها مع الحصول على الصلاحيات المناسبة
            return []
        except Exception as e:
            logger.error(f"خطأ في جلب منشورات Instagram: {e}")
            return []
    
    async def fetch_tiktok_posts(self, username: str) -> List[SocialMediaPost]:
        """جلب منشورات TikTok"""
        try:
            # هذه الدالة تحتاج TikTok API Token
            # يمكن تطويرها مع الحصول على الصلاحيات المناسبة
            return []
        except Exception as e:
            logger.error(f"خطأ في جلب منشورات TikTok: {e}")
            return []
    
    async def post_facebook_reply(self, post_id: str, comment_id: str, message: str):
        """نشر رد على Facebook"""
        try:
            # نشر الرد باستخدام Facebook Graph API
            # يحتاج Facebook Page Access Token
            pass
        except Exception as e:
            logger.error(f"خطأ في نشر الرد على Facebook: {e}")
    
    async def post_instagram_reply(self, post_id: str, comment_id: str, message: str):
        """نشر رد على Instagram"""
        try:
            # نشر الرد باستخدام Instagram Basic Display API
            # يحتاج Instagram Access Token
            pass
        except Exception as e:
            logger.error(f"خطأ في نشر الرد على Instagram: {e}")
    
    async def post_tiktok_reply(self, post_id: str, comment_id: str, message: str):
        """نشر رد على TikTok"""
        try:
            # نشر الرد باستخدام TikTok API
            # يحتاج TikTok Access Token
            pass
        except Exception as e:
            logger.error(f"خطأ في نشر الرد على TikTok: {e}")
    
    # دوال مساعدة
    def extract_facebook_page_id(self, url: str) -> Optional[str]:
        """استخراج معرف صفحة Facebook"""
        try:
            # استخراج معرف الصفحة من الرابط
            import re
            match = re.search(r'facebook\.com/([^/]+)', url)
            return match.group(1) if match else None
        except Exception as e:
            logger.error(f"خطأ في استخراج معرف Facebook: {e}")
            return None
    
    def extract_instagram_username(self, url: str) -> Optional[str]:
        """استخراج اسم المستخدم Instagram"""
        try:
            import re
            match = re.search(r'instagram\.com/([^/]+)', url)
            return match.group(1) if match else None
        except Exception as e:
            logger.error(f"خطأ في استخراج اسم المستخدم Instagram: {e}")
            return None
    
    def extract_tiktok_username(self, url: str) -> Optional[str]:
        """استخراج اسم المستخدم TikTok"""
        try:
            import re
            match = re.search(r'tiktok\.com/@([^/]+)', url)
            return match.group(1) if match else None
        except Exception as e:
            logger.error(f"خطأ في استخراج اسم المستخدم TikTok: {e}")
            return None
    
    def stop_monitoring(self):
        """إيقاف المراقبة"""
        self.monitoring_active = False
        logger.info("🛑 تم إيقاف مراقبة الصفحات")
    
    def toggle_auto_reply(self, enabled: bool):
        """تفعيل/إلغاء الرد التلقائي"""
        self.auto_reply_enabled = enabled
        status = "مفعل" if enabled else "معطل"
        logger.info(f"🔄 الرد التلقائي {status}")
    
    def get_monitoring_status(self) -> Dict:
        """الحصول على حالة المراقبة"""
        return {
            'monitoring_active': self.monitoring_active,
            'auto_reply_enabled': self.auto_reply_enabled,
            'active_sessions': len(self.active_sessions)
        }